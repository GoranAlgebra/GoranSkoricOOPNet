using System;
using System.IO;

namespace ClassLibrary.Helpers
{
    public static class ImageHelper
    {
        private static string BaseDirectory => AppDomain.CurrentDomain.BaseDirectory;
        private const string DefaultImageRelativePath = "Resources/DefaultPlayerPic.jpeg";
        private static string DefaultImagePath => Path.Combine(BaseDirectory, DefaultImageRelativePath);
        
        // Get the ClassLibrary source directory for saving new images
        private static string ClassLibrarySourceDirectory
        {
            get
            {
                // Find the ClassLibrary source directory by looking for the .csproj file
                string currentDir = BaseDirectory;
                while (!string.IsNullOrEmpty(currentDir))
                {
                    string classLibraryPath = Path.Combine(currentDir, "ClassLibrary");
                    if (Directory.Exists(classLibraryPath) && File.Exists(Path.Combine(classLibraryPath, "ClassLibrary.csproj")))
                    {
                        return Path.Combine(classLibraryPath, "Data", "PlayerImages");
                    }
                    
                    string parentDir = Path.GetDirectoryName(currentDir);
                    if (parentDir == currentDir) break;
                    currentDir = parentDir;
                }
                
                // Fallback: use the current app's directory
                return Path.Combine(BaseDirectory, "Data", "PlayerImages");
            }
        }

        // Use the Data/PlayerImages directory that gets copied to the output for reading
        private static string CustomImagesDirectory => Path.Combine(BaseDirectory, "Data", "PlayerImages");

        public static string GetPlayerImagePath(string imageFileName)
        {
            if (string.IsNullOrEmpty(imageFileName))
            {
                return DefaultImagePath;
            }

            string customPath = Path.Combine(CustomImagesDirectory, imageFileName);
            return File.Exists(customPath) ? customPath : DefaultImagePath;
        }

        public static string SaveImageFromPath(string sourcePath, string playerName)
        {
            try
            {
                // Save to ClassLibrary source directory first
                Directory.CreateDirectory(ClassLibrarySourceDirectory);

                // Use a default name if playerName is null or whitespace
                string baseName = string.IsNullOrWhiteSpace(playerName) ? "Player" : playerName;

                // Sanitize player name to create a valid file name
                string invalidChars = new string(Path.GetInvalidFileNameChars());
                string sanitizedPlayerName = baseName;
                foreach (char c in invalidChars)
                {
                    sanitizedPlayerName = sanitizedPlayerName.Replace(c.ToString(), "");
                }

                var newFileName = $"{sanitizedPlayerName}_{Guid.NewGuid()}{Path.GetExtension(sourcePath)}";
                var classLibraryPath = Path.Combine(ClassLibrarySourceDirectory, newFileName);
                
                // Copy to ClassLibrary source
                File.Copy(sourcePath, classLibraryPath, true);
                
                // Also copy to current app's directory for immediate access
                Directory.CreateDirectory(CustomImagesDirectory);
                var appPath = Path.Combine(CustomImagesDirectory, newFileName);
                File.Copy(sourcePath, appPath, true);
                
                return newFileName;
            }
            catch (Exception ex)
            {
                // Optionally log the exception
                return null;
            }
        }

        public static bool SavePlayerImage(string imageFileName, byte[] imageData)
        {
            try
            {
                // Save to ClassLibrary source directory first
                Directory.CreateDirectory(ClassLibrarySourceDirectory);
                string classLibraryPath = Path.Combine(ClassLibrarySourceDirectory, imageFileName);
                File.WriteAllBytes(classLibraryPath, imageData);
                
                // Also save to current app's directory
                Directory.CreateDirectory(CustomImagesDirectory);
                string appPath = Path.Combine(CustomImagesDirectory, imageFileName);
                File.WriteAllBytes(appPath, imageData);
                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
} 