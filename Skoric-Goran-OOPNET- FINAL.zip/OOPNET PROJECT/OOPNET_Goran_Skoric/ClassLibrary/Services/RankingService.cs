using ClassLibrary.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLibrary.Services
{
    public class RankingService
    {
        private readonly WorldCupService _worldCupService;
        
        public RankingService()
        {
            _worldCupService = new WorldCupService();
        }

        public async Task<List<Player>> GetPlayerRankings(string fifaCode, string gender)
        {
            var matches = await _worldCupService.GetMatchesByCountryAsync(fifaCode, gender);

            var playerStats = new Dictionary<string, Player>();

            foreach (var match in matches)
            {
                var team = match.HomeTeam.Code == fifaCode ? match.HomeTeamStatistics : match.AwayTeamStatistics;
                var teamEvents = match.HomeTeam.Code == fifaCode ? match.HomeTeamEvents : match.AwayTeamEvents;

                var playersInMatch = team.StartingEleven.Concat(team.Substitutes);

                foreach (var player in playersInMatch)
                {
                    if (!playerStats.ContainsKey(player.Name))
                    {
                        playerStats[player.Name] = new Player
                        {
                            Name = player.Name,
                            FullName = player.Name,
                            Appearances = 0,
                            GoalsScored = 0,
                            YellowCards = 0,
                            ShirtNumber = player.ShirtNumber,
                            Position = player.Position,
                            IsCaptain = player.Captain
                        };
                    }
                    playerStats[player.Name].Appearances++;
                    if (player.Captain)
                    {
                        playerStats[player.Name].IsCaptain = true;
                    }
                }

                foreach (var ev in teamEvents)
                {
                    if (playerStats.ContainsKey(ev.PlayerName))
                    {
                        switch (ev.TypeOfEvent)
                        {
                            case "goal":
                            case "goal-penalty":
                                playerStats[ev.PlayerName].GoalsScored++;
                                break;
                            case "yellow-card":
                                playerStats[ev.PlayerName].YellowCards++;
                                break;
                        }
                    }
                }
            }

            return playerStats.Values
                .OrderByDescending(p => p.GoalsScored)
                .ThenBy(p => p.YellowCards)
                .ThenByDescending(p => p.Appearances)
                .ToList();
        }

        public List<MatchRanking> CalculateMatchRankings(List<MatchRanking> matches)
        {
            return matches
                .OrderByDescending(m => m.Visitors)
                .ToList();
        }
    }
} 