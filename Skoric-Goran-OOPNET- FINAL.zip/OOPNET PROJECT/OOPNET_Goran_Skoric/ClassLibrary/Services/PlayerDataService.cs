using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.IO;
using ClassLibrary.Models;

namespace ClassLibrary.Services
{
    public class PlayerDataService
    {
        // Define a base directory for all data files, relative to the executing assembly's location
        private static string BaseDataDirectory => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data");

        // Define gender-specific data directories
        public static string MenDataDirectory => Path.Combine(BaseDataDirectory, "Male");
        public static string WomenDataDirectory => Path.Combine(BaseDataDirectory, "Female");

        // Define source data directories by navigating from the output directory to the solution's source folder
        private static string SourceBaseDataDirectory => Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\ClassLibrary\Data"));
        private static string SourceMenDataDirectory => Path.Combine(SourceBaseDataDirectory, "Male");
        private static string SourceWomenDataDirectory => Path.Combine(SourceBaseDataDirectory, "Female");

        // Define full paths for data files
        private static string MenPlayersFile => Path.Combine(MenDataDirectory, "men_players.json");
        private static string WomenPlayersFile => Path.Combine(WomenDataDirectory, "women_players.json");
        private static string MenPlayerRankingsFile => Path.Combine(MenDataDirectory, "men_player_rankings.json");
        private static string WomenPlayerRankingsFile => Path.Combine(WomenDataDirectory, "women_player_rankings.json");
        private static string MenMatchVisitorsFile => Path.Combine(MenDataDirectory, "men_match_visitors.json");
        private static string WomenMatchVisitorsFile => Path.Combine(WomenDataDirectory, "women_match_visitors.json");

        // Define source data file paths
        private static string SourceMenPlayersFile => Path.Combine(SourceMenDataDirectory, "men_players.json");
        private static string SourceWomenPlayersFile => Path.Combine(SourceWomenDataDirectory, "women_players.json");

        public PlayerDataService()
        {
            // Ensure data directories exist when the service is instantiated
            Directory.CreateDirectory(MenDataDirectory);
            Directory.CreateDirectory(WomenDataDirectory);
        }

        public async Task<(bool success, string logMessage)> SaveTeamPlayers(string gender)
        {
            string logMessage = "";
            try
            {
                string dataFile = gender == "Men" ? WorldCupService.MenDataFile : WorldCupService.WomenDataFile;
                string outputFile = gender == "Men" ? MenPlayersFile : WomenPlayersFile;

                logMessage += $"[PlayerDataService] Starting SaveTeamPlayers for {gender}\n";
                logMessage += $"[PlayerDataService] Reading from {dataFile}\n";

                if (!File.Exists(dataFile))
                {
                    logMessage += $"[PlayerDataService] Error: World Cup data file not found: {dataFile}\n";
                    return (false, logMessage);
                }

                string json = await File.ReadAllTextAsync(dataFile);
                using JsonDocument doc = JsonDocument.Parse(json);
                JsonElement worldCupData = doc.RootElement;

                var teamPlayers = new List<TeamPlayers>();
                var processedTeams = new HashSet<string>();
                var playerStatsMap = new Dictionary<string, Player>();

                // Load all teams from the "Teams" section for lookup
                // We will use fifa_code as the key for lookup
                Dictionary<string, JsonElement> allTeamsLookup = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
                if (worldCupData.TryGetProperty("Teams", out JsonElement teamsElement) && teamsElement.ValueKind == JsonValueKind.Array)
                {
                    foreach (var team in teamsElement.EnumerateArray())
                    {
                        if (team.TryGetProperty("fifa_code", out JsonElement teamFifaCodeElement) && teamFifaCodeElement.ValueKind == JsonValueKind.String)
                        {
                            allTeamsLookup[teamFifaCodeElement.GetString()] = team;
                        }
                    }
                    logMessage += $"[PlayerDataService] Loaded {allTeamsLookup.Count} teams for lookup by FIFA code.\n";
                }
                else
                {
                    logMessage += $"[PlayerDataService] Warning: 'Teams' array not found or not in expected format in {dataFile}. Team details might be incomplete.\n";
                }

                if (worldCupData.TryGetProperty("Matches", out JsonElement matchesElement) && matchesElement.ValueKind == JsonValueKind.Array)
                {
                    int matchCount = matchesElement.EnumerateArray().Count();
                    logMessage += $"[PlayerDataService] Found {matchCount} matches in the data\n";

                    // First pass: Calculate player statistics from all matches
                    foreach (var match in matchesElement.EnumerateArray())
                    {
                        ProcessMatchForPlayerStats(match, playerStatsMap, ref logMessage);
                    }

                    logMessage += $"[PlayerDataService] Calculated statistics for {playerStatsMap.Count} players\n";

                    // Second pass: Build team players with statistics
                    foreach (var match in matchesElement.EnumerateArray())
                    {
                        if (match.TryGetProperty("home_team", out JsonElement homeTeamIdentifier) &&
                            match.TryGetProperty("home_team_statistics", out JsonElement homeTeamStats) &&
                            match.TryGetProperty("away_team", out JsonElement awayTeamIdentifier) &&
                            match.TryGetProperty("away_team_statistics", out JsonElement awayTeamStats))
                        {
                            // Get the FIFA code from the home_team identifier in the match data
                            string homeTeamCode = null;
                            if (homeTeamIdentifier.TryGetProperty("code", out JsonElement homeCodeElement) && homeCodeElement.ValueKind == JsonValueKind.String)
                            {
                                homeTeamCode = homeCodeElement.GetString();
                            }

                            // Use the FIFA code to get the full team object from the lookup
                            JsonElement homeTeam = default;
                            if (homeTeamCode != null && allTeamsLookup.TryGetValue(homeTeamCode, out homeTeam))
                            {
                                ProcessTeamWithLoggingAndStats(homeTeam, homeTeamStats, teamPlayers, processedTeams, "home", playerStatsMap, ref logMessage);
                            }
                            else
                            {
                                logMessage += $"[PlayerDataService] Warning: Full home team data not found for code '{homeTeamCode ?? homeTeamIdentifier.GetRawText()}'. Skipping.\n";
                            }

                            // Get the FIFA code from the away_team identifier in the match data
                            string awayTeamCode = null;
                            if (awayTeamIdentifier.TryGetProperty("code", out JsonElement awayCodeElement) && awayCodeElement.ValueKind == JsonValueKind.String)
                            {
                                awayTeamCode = awayCodeElement.GetString();
                            }

                            // Use the FIFA code to get the full team object from the lookup
                            JsonElement awayTeam = default;
                            if (awayTeamCode != null && allTeamsLookup.TryGetValue(awayTeamCode, out awayTeam))
                            {
                                ProcessTeamWithLoggingAndStats(awayTeam, awayTeamStats, teamPlayers, processedTeams, "away", playerStatsMap, ref logMessage);
                            }
                            else
                            {
                                logMessage += $"[PlayerDataService] Warning: Full away team data not found for code '{awayTeamCode ?? awayTeamIdentifier.GetRawText()}'. Skipping.\n";
                            }
                        }
                        else
                        {
                            logMessage += "[PlayerDataService] Warning: Skipping match due to missing team or statistics properties\n";
                        }
                    }
                }
                else
                {
                    logMessage += $"[PlayerDataService] Error: 'Matches' array not found or not in expected format in {dataFile}\n";
                    return (false, logMessage);
                }

                logMessage += $"[PlayerDataService] Processed {teamPlayers.Count} unique teams with players\n";
                foreach (var team in teamPlayers)
                {
                    logMessage += $"[PlayerDataService] Team: {team.TeamName} ({team.FifaCode}), Players: {team.Players.Count}\n";
                }

                string outputJson = JsonSerializer.Serialize(teamPlayers, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(outputFile, outputJson);
                logMessage += $"[PlayerDataService] Successfully saved team players to {outputFile}\n";

                return (true, logMessage);
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Exception in SaveTeamPlayers: {ex.Message}\n";
                return (false, logMessage);
            }
        }

        private void ProcessTeamWithLoggingAndStats(JsonElement team, JsonElement teamStats, List<TeamPlayers> teamPlayers, HashSet<string> processedTeams, string teamType, Dictionary<string, Player> playerStatsMap, ref string logMessage)
        {
            string teamName = null;
            string fifaCode = null;

            logMessage += $"[PlayerDataService] Debug: Entering ProcessTeamWithLoggingAndStats for {teamType} team. Raw team JSON: {team.GetRawText()}\n";

            // Prioritize 'name' for team name, then 'country'
            if (team.TryGetProperty("name", out JsonElement nameElement) && nameElement.ValueKind == JsonValueKind.String)
            {
                teamName = nameElement.GetString();
            }
            else if (team.TryGetProperty("country", out JsonElement countryElement) && countryElement.ValueKind == JsonValueKind.String)
            {
                teamName = countryElement.GetString();
            }

            // Extract fifa_code
            if (team.TryGetProperty("fifa_code", out JsonElement fifaCodeElement))
            {
                logMessage += $"[PlayerDataService] Debug: 'fifa_code' element found for team {teamName}. ValueKind: {fifaCodeElement.ValueKind}\n";
                if (fifaCodeElement.ValueKind == JsonValueKind.String)
                {
                    fifaCode = fifaCodeElement.GetString();
                }
                else
                {
                    logMessage += $"[PlayerDataService] Warning: 'fifa_code' property found but not a string (ValueKind: {fifaCodeElement.ValueKind}) for team {teamName}\n";
                }
            }
            else
            {
                logMessage += $"[PlayerDataService] Warning: 'fifa_code' property not found for team {teamName}\n";
            }

            logMessage += $"[PlayerDataService] Processing {teamType} team: {teamName} (FIFA Code: {fifaCode ?? "N/A"})\n";

            if (string.IsNullOrEmpty(teamName) || string.IsNullOrEmpty(fifaCode))
            {
                logMessage += $"[PlayerDataService] Warning: Skipping team due to missing 'teamName' ({teamName ?? "N/A"}) or 'fifaCode' ({fifaCode ?? "N/A"})\n";
                return;
            }

            if (processedTeams.Contains(fifaCode))
            {
                logMessage += $"[PlayerDataService] Skipping already processed team: {teamName} ({fifaCode})\n";
                return;
            }

            var teamPlayerList = new TeamPlayers
            {
                TeamName = teamName,
                FifaCode = fifaCode,
                Players = new List<Player>()
            };

            // Process starting eleven players
            if (teamStats.TryGetProperty("starting_eleven", out JsonElement startingElevenElement) && startingElevenElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var playerElement in startingElevenElement.EnumerateArray())
                {
                    Player player = ExtractPlayerFromElementWithStats(playerElement, playerStatsMap);
                    if (player != null)
                    {
                        teamPlayerList.Players.Add(player);
                    }
                }
            }

            // Process substitute players
            if (teamStats.TryGetProperty("substitutes", out JsonElement substitutesElement) && substitutesElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var playerElement in substitutesElement.EnumerateArray())
                {
                    Player player = ExtractPlayerFromElementWithStats(playerElement, playerStatsMap);
                    if (player != null)
                    {
                        teamPlayerList.Players.Add(player);
                    }
                }
            }

            teamPlayers.Add(teamPlayerList);
            processedTeams.Add(fifaCode);
            logMessage += $"[PlayerDataService] Successfully processed team {teamName} with {teamPlayerList.Players.Count} players\n";
        }

        private Player ExtractPlayerFromElementWithStats(JsonElement playerElement, Dictionary<string, Player> playerStatsMap)
        {
            try
            {
                if (playerElement.TryGetProperty("name", out JsonElement nameElement) && nameElement.ValueKind == JsonValueKind.String)
                {
                    string playerName = nameElement.GetString();
                    
                    // Create base player from element
                    Player player = new Player
                    {
                        Name = playerName,
                        FullName = playerName,
                        ShirtNumber = playerElement.TryGetProperty("shirt_number", out JsonElement shirtNumber) ? shirtNumber.GetInt32() : 0,
                        Position = playerElement.TryGetProperty("position", out JsonElement position) ? position.GetString() : "",
                        IsCaptain = playerElement.TryGetProperty("captain", out JsonElement captain) && captain.ValueKind == JsonValueKind.True,
                        Appearances = 0,
                        GoalsScored = 0,
                        YellowCards = 0,
                        ImageFileName = ""
                    };

                    // Merge with calculated statistics if available
                    if (playerStatsMap.TryGetValue(playerName, out Player statsPlayer))
                    {
                        player.Appearances = statsPlayer.Appearances;
                        player.GoalsScored = statsPlayer.GoalsScored;
                        player.YellowCards = statsPlayer.YellowCards;
                    }

                    return player;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error extracting player from element: {ex.Message}");
            }

            return null;
        }

        private void ProcessTeamWithLogging(JsonElement team, JsonElement teamStats, List<TeamPlayers> teamPlayers, HashSet<string> processedTeams, string teamType, ref string logMessage)
        {
            string teamName = null;
            string fifaCode = null;

            logMessage += $"[PlayerDataService] Debug: Entering ProcessTeamWithLogging for {teamType} team. Raw team JSON: {team.GetRawText()}\n";

            // Prioritize 'name' for team name, then 'country'
            if (team.TryGetProperty("name", out JsonElement nameElement) && nameElement.ValueKind == JsonValueKind.String)
            {
                teamName = nameElement.GetString();
            }
            else if (team.TryGetProperty("country", out JsonElement countryElement) && countryElement.ValueKind == JsonValueKind.String)
            {
                teamName = countryElement.GetString();
            }

            // Extract fifa_code
            if (team.TryGetProperty("fifa_code", out JsonElement fifaCodeElement))
            {
                logMessage += $"[PlayerDataService] Debug: 'fifa_code' element found for team {teamName}. ValueKind: {fifaCodeElement.ValueKind}\n";
                if (fifaCodeElement.ValueKind == JsonValueKind.String)
                {
                    fifaCode = fifaCodeElement.GetString();
                }
                else
                {
                    logMessage += $"[PlayerDataService] Warning: 'fifa_code' property found but not a string (ValueKind: {fifaCodeElement.ValueKind}) for team {teamName}\n";
                }
            }
            else
            {
                logMessage += $"[PlayerDataService] Warning: 'fifa_code' property not found for team {teamName}\n";
            }

            logMessage += $"[PlayerDataService] Processing {teamType} team: {teamName} (FIFA Code: {fifaCode ?? "N/A"})\n";

            if (string.IsNullOrEmpty(teamName) || string.IsNullOrEmpty(fifaCode))
            {
                logMessage += $"[PlayerDataService] Warning: Skipping team due to missing 'teamName' ({teamName ?? "N/A"}) or 'fifaCode' ({fifaCode ?? "N/A"})\n";
                return;
            }

            if (processedTeams.Contains(fifaCode))
            {
                logMessage += $"[PlayerDataService] Skipping already processed team: {teamName} ({fifaCode})\n";
                return;
            }

            var teamPlayerList = new TeamPlayers
            {
                TeamName = teamName,
                FifaCode = fifaCode,
                Players = new List<Player>()
            };

            // Process starting eleven players
            if (teamStats.TryGetProperty("starting_eleven", out JsonElement startingElevenElement) && startingElevenElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var playerElement in startingElevenElement.EnumerateArray())
                {
                    Player player = ExtractPlayerFromElement(playerElement);
                    if (player != null)
                    {
                        teamPlayerList.Players.Add(player);
                    }
                }
            }

            // Process substitute players
            if (teamStats.TryGetProperty("substitutes", out JsonElement substitutesElement) && substitutesElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var playerElement in substitutesElement.EnumerateArray())
                {
                    Player player = ExtractPlayerFromElement(playerElement);
                    if (player != null)
                    {
                        teamPlayerList.Players.Add(player);
                    }
                }
            }

            teamPlayers.Add(teamPlayerList);
            processedTeams.Add(fifaCode);
            logMessage += $"[PlayerDataService] Successfully processed team {teamName} with {teamPlayerList.Players.Count} players\n";
        }

        public async Task SavePlayerRankings(string gender)
        {
            string logMessage = "";
            try
            {
                string dataFile = gender == "Men" ? WorldCupService.MenDataFile : WorldCupService.WomenDataFile;
                string outputFile = gender == "Men" ? MenPlayerRankingsFile : WomenPlayerRankingsFile;

                logMessage += $"[PlayerDataService] Starting SavePlayerRankings for {gender}\n";
                logMessage += $"[PlayerDataService] Reading from {dataFile}\n";

                if (!File.Exists(dataFile))
                {
                    logMessage += $"[PlayerDataService] Error: World Cup data file not found: {dataFile}\n";
                    return;
                }

                string json = await File.ReadAllTextAsync(dataFile);
                using JsonDocument doc = JsonDocument.Parse(json);
                JsonElement worldCupData = doc.RootElement;

                // Dictionary to aggregate stats per player
                var playerStatsMap = new Dictionary<string, Player>(StringComparer.OrdinalIgnoreCase);

                if (worldCupData.TryGetProperty("Matches", out JsonElement matchesElement) && matchesElement.ValueKind == JsonValueKind.Array)
                {
                    logMessage += $"[PlayerDataService] Processing {matchesElement.EnumerateArray().Count()} matches\n";

                    foreach (var match in matchesElement.EnumerateArray())
                    {
                        ProcessMatchForPlayerStats(match, playerStatsMap, ref logMessage);
                    }
                }
                else
                {
                    logMessage += $"[PlayerDataService] Error: 'Matches' array not found or not in expected format in {dataFile}\n";
                    return;
                }

                // Convert dictionary values to list and sort by goals (desc), yellow cards (asc), appearances (desc)
                var sortedPlayers = playerStatsMap.Values
                    .OrderByDescending(p => p.GoalsScored)
                    .ThenBy(p => p.YellowCards)
                    .ThenByDescending(p => p.Appearances)
                    .ThenBy(p => p.FullName)
                    .ToList();

                logMessage += $"[PlayerDataService] Generated rankings for {sortedPlayers.Count} players\n";

                string outputJson = JsonSerializer.Serialize(sortedPlayers, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(outputFile, outputJson);
                logMessage += $"[PlayerDataService] Successfully saved player rankings to {outputFile}\n";
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Exception in SavePlayerRankings: {ex.Message}\n";
            }
        }

        private void ProcessMatchForPlayerStats(JsonElement match, Dictionary<string, Player> playerStatsMap, ref string logMessage)
        {
            try
            {
                // Get home and away team info
                if (!match.TryGetProperty("home_team", out JsonElement homeTeam) || 
                    !match.TryGetProperty("away_team", out JsonElement awayTeam))
                {
                    return;
                }

                string homeTeamCode = homeTeam.TryGetProperty("code", out JsonElement homeCode) ? homeCode.GetString() : "";
                string awayTeamCode = awayTeam.TryGetProperty("code", out JsonElement awayCode) ? awayCode.GetString() : "";

                // Get team statistics
                if (!match.TryGetProperty("home_team_statistics", out JsonElement homeTeamStats) ||
                    !match.TryGetProperty("away_team_statistics", out JsonElement awayTeamStats))
                {
                    return;
                }

                // Get team events
                if (!match.TryGetProperty("home_team_events", out JsonElement homeTeamEvents) ||
                    !match.TryGetProperty("away_team_events", out JsonElement awayTeamEvents))
                {
                    return;
                }

                // Process home team
                ProcessTeamStats(homeTeamStats, homeTeamEvents, playerStatsMap, ref logMessage);
                
                // Process away team
                ProcessTeamStats(awayTeamStats, awayTeamEvents, playerStatsMap, ref logMessage);
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Error processing match: {ex.Message}\n";
            }
        }

        private void ProcessTeamStats(JsonElement teamStats, JsonElement teamEvents, Dictionary<string, Player> playerStatsMap, ref string logMessage)
        {
            try
            {
                // Process appearances from starting eleven and substitutes
                if (teamStats.TryGetProperty("starting_eleven", out JsonElement startingEleven) && startingEleven.ValueKind == JsonValueKind.Array)
                {
                    foreach (var playerElement in startingEleven.EnumerateArray())
                    {
                        ProcessPlayerAppearance(playerElement, playerStatsMap);
                    }
                }

                if (teamStats.TryGetProperty("substitutes", out JsonElement substitutes) && substitutes.ValueKind == JsonValueKind.Array)
                {
                    foreach (var playerElement in substitutes.EnumerateArray())
                    {
                        ProcessPlayerAppearance(playerElement, playerStatsMap);
                    }
                }

                // Process events (goals and yellow cards)
                if (teamEvents.ValueKind == JsonValueKind.Array)
                {
                    foreach (var eventElement in teamEvents.EnumerateArray())
                    {
                        ProcessPlayerEvent(eventElement, playerStatsMap);
                    }
                }
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Error processing team stats: {ex.Message}\n";
            }
        }

        private void ProcessPlayerAppearance(JsonElement playerElement, Dictionary<string, Player> playerStatsMap)
        {
            try
            {
                if (playerElement.TryGetProperty("name", out JsonElement nameElement) && nameElement.ValueKind == JsonValueKind.String)
                {
                    string playerName = nameElement.GetString();
                    
                    if (!playerStatsMap.TryGetValue(playerName, out Player player))
                    {
                        // Create new player entry
                        player = new Player
                        {
                            Name = playerName,
                            FullName = playerName,
                            ShirtNumber = playerElement.TryGetProperty("shirt_number", out JsonElement shirtNumber) ? shirtNumber.GetInt32() : 0,
                            Position = playerElement.TryGetProperty("position", out JsonElement position) ? position.GetString() : "",
                            IsCaptain = playerElement.TryGetProperty("captain", out JsonElement captain) && captain.ValueKind == JsonValueKind.True,
                            Appearances = 0,
                            GoalsScored = 0,
                            YellowCards = 0,
                            ImageFileName = null
                        };
                        playerStatsMap[playerName] = player;
                    }
                    
                    player.Appearances++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing player appearance: {ex.Message}");
            }
        }

        private void ProcessPlayerEvent(JsonElement eventElement, Dictionary<string, Player> playerStatsMap)
        {
            try
            {
                if (eventElement.TryGetProperty("player", out JsonElement playerElement) && 
                    eventElement.TryGetProperty("type_of_event", out JsonElement eventTypeElement))
                {
                    string playerName = playerElement.GetString();
                    string eventType = eventTypeElement.GetString();

                    if (playerStatsMap.TryGetValue(playerName, out Player player))
                    {
                        switch (eventType.ToLower())
                        {
                            case "goal":
                                player.GoalsScored++;
                                break;
                            case "yellow-card":
                                player.YellowCards++;
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing player event: {ex.Message}");
            }
        }

        public async Task SaveMatchVisitorRankings(string gender)
        {
            string logMessage = "";
            try
            {
                string dataFile = gender == "Men" ? WorldCupService.MenDataFile : WorldCupService.WomenDataFile;
                string outputFile = gender == "Men" ? MenMatchVisitorsFile : WomenMatchVisitorsFile;

                logMessage += $"[PlayerDataService] Starting SaveMatchVisitorRankings for {gender}\n";
                logMessage += $"[PlayerDataService] Reading from {dataFile}\n";

                if (!File.Exists(dataFile))
                {
                    logMessage += $"[PlayerDataService] Error: World Cup data file not found: {dataFile}\n";
                    return;
                }

                string json = await File.ReadAllTextAsync(dataFile);
                using JsonDocument doc = JsonDocument.Parse(json);
                JsonElement worldCupData = doc.RootElement;

                var matchRankings = new List<MatchRanking>();

                if (worldCupData.TryGetProperty("Matches", out JsonElement matchesElement) && matchesElement.ValueKind == JsonValueKind.Array)
                {
                    foreach (var match in matchesElement.EnumerateArray())
                    {
                        if (match.TryGetProperty("venue", out JsonElement venueElement) && venueElement.ValueKind == JsonValueKind.String &&
                            match.TryGetProperty("location", out JsonElement locationElement) && locationElement.ValueKind == JsonValueKind.String &&
                            match.TryGetProperty("home_team", out JsonElement homeTeamElement) && homeTeamElement.ValueKind == JsonValueKind.Object &&
                            match.TryGetProperty("away_team", out JsonElement awayTeamElement) && awayTeamElement.ValueKind == JsonValueKind.Object &&
                            match.TryGetProperty("attendance", out JsonElement attendanceElement) && attendanceElement.ValueKind == JsonValueKind.String)
                        {
                            string homeTeamName = homeTeamElement.TryGetProperty("country", out JsonElement homeCountry) ? homeCountry.GetString() : "Unknown Home Team";
                            string awayTeamName = awayTeamElement.TryGetProperty("country", out JsonElement awayCountry) ? awayCountry.GetString() : "Unknown Away Team";

                            MatchRanking ranking = new MatchRanking
                            {
                                Location = venueElement.GetString(),
                                Venue = locationElement.GetString(),
                                HomeTeam = homeTeamName,
                                AwayTeam = awayTeamName,
                                Visitors = int.Parse(attendanceElement.GetString())
                            };
                            matchRankings.Add(ranking);
                        }
                    }
                }

                // Sort by attendance in descending order
                var sortedRankings = matchRankings.OrderByDescending(m => m.Visitors).ToList();

                string outputJson = JsonSerializer.Serialize(sortedRankings, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(outputFile, outputJson);
                logMessage += $"[PlayerDataService] Successfully saved match visitor rankings to {outputFile}\n";
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Exception in SaveMatchVisitorRankings: {ex.Message}\n";
            }
        }

        private Player ExtractPlayerFromElement(JsonElement playerElement)
        {
            try
            {
                if (playerElement.ValueKind == JsonValueKind.Object)
                {
                    return new Player
                    {
                        Name = playerElement.TryGetProperty("name", out JsonElement name) ? name.GetString() : "",
                        FullName = playerElement.TryGetProperty("name", out JsonElement fullName) ? fullName.GetString() : "", // Assuming name is full name
                        ShirtNumber = playerElement.TryGetProperty("shirt_number", out JsonElement shirtNumber) ? shirtNumber.GetInt32() : 0,
                        Position = playerElement.TryGetProperty("position", out JsonElement position) ? position.GetString() : "",
                        IsCaptain = playerElement.TryGetProperty("captain", out JsonElement captain) && captain.ValueKind == JsonValueKind.True, // Extract IsCaptain
                        Goals = playerElement.TryGetProperty("goals", out JsonElement goals) ? goals.GetInt32() : 0,
                        YellowCards = playerElement.TryGetProperty("yellow_cards", out JsonElement yellowCards) ? yellowCards.GetInt32() : 0,
                        // ImageFileName will be handled separately, not directly from JSON
                        ImageFileName = null
                    };
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error extracting player from JSON element: {ex.Message}");
            }
            return null;
        }

        public async Task<List<TeamPlayers>> LoadTeamPlayers(string gender)
        {
            string inputFile = gender == "Men" ? MenPlayersFile : WomenPlayersFile;
            if (File.Exists(inputFile))
            {
                string json = await File.ReadAllTextAsync(inputFile);
                return JsonSerializer.Deserialize<List<TeamPlayers>>(json);
            }
            return new List<TeamPlayers>();
        }

        public async Task<List<Player>> LoadPlayerRankings(string gender)
        {
            string inputFile = gender == "Men" ? MenPlayerRankingsFile : WomenPlayerRankingsFile;
            if (File.Exists(inputFile))
            {
                string json = await File.ReadAllTextAsync(inputFile);
                return JsonSerializer.Deserialize<List<Player>>(json);
            }
            return new List<Player>();
        }

        public async Task<List<MatchRanking>> LoadMatchVisitorRankings(string gender)
        {
            string inputFile = gender == "Men" ? MenMatchVisitorsFile : WomenMatchVisitorsFile;
            if (File.Exists(inputFile))
            {
                string json = await File.ReadAllTextAsync(inputFile);
                return JsonSerializer.Deserialize<List<MatchRanking>>(json);
            }
            return new List<MatchRanking>();
        }

        public async Task<(bool success, string logMessage)> ResetAllPlayerImagesToDefault()
        {
            string logMessage = "";
            try
            {
                // Process Men's data
                var (menSuccess, menLog) = await ResetPlayerImagesInFile(WorldCupService.MenDataFile);
                logMessage += menLog;
                
                // Process Women's data
                var (womenSuccess, womenLog) = await ResetPlayerImagesInFile(WorldCupService.WomenDataFile);
                logMessage += womenLog;

                return (menSuccess && womenSuccess, logMessage);
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Error in ResetAllPlayerImagesToDefault: {ex.Message}\n";
                return (false, logMessage);
            }
        }

        private async Task<(bool success, string logMessage)> ResetPlayerImagesInFile(string filePath)
        {
            string logMessage = "";
            if (!File.Exists(filePath))
            {
                logMessage += $"[PlayerDataService] Error: Data file not found: {filePath}. Skipping image reset.\n";
                return (false, logMessage);
            }

            try
            {
                string json = await File.ReadAllTextAsync(filePath);
                var options = new JsonSerializerOptions { WriteIndented = true };
                
                // Deserialize the entire JSON into our structured models
                WorldCupDataModel worldCupData = JsonSerializer.Deserialize<WorldCupDataModel>(json, options);

                if (worldCupData?.Matches != null)
                {
                    foreach (var match in worldCupData.Matches)
                    {
                        // Reset images in home team statistics
                        if (match.HomeTeamStatistics?.StartingEleven != null)
                        {
                            foreach (var player in match.HomeTeamStatistics.StartingEleven)
                            {
                                player.ImageFileName = null;
                            }
                        }
                        if (match.HomeTeamStatistics?.Substitutes != null)
                        {
                            foreach (var player in match.HomeTeamStatistics.Substitutes)
                            {
                                player.ImageFileName = null;
                            }
                        }

                        // Reset images in away team statistics
                        if (match.AwayTeamStatistics?.StartingEleven != null)
                        {
                            foreach (var player in match.AwayTeamStatistics.StartingEleven)
                            {
                                player.ImageFileName = null;
                            }
                        }
                        if (match.AwayTeamStatistics?.Substitutes != null)
                        {
                            foreach (var player in match.AwayTeamStatistics.Substitutes)
                            {
                                player.ImageFileName = null;
                            }
                        }
                    }
                }

                // Reserialize the modified data back to the file
                string updatedJson = JsonSerializer.Serialize(worldCupData, options);
                await File.WriteAllTextAsync(filePath, updatedJson);
                logMessage += $"[PlayerDataService] Successfully reset images in {filePath}\n";
                return (true, logMessage);
            }
            catch (Exception ex)
            {
                logMessage += $"[PlayerDataService] Error resetting images in {filePath}: {ex.Message}\n";
                return (false, logMessage);
            }
        }

        public async Task UpdatePlayerImage(string playerName, string newImageFileName, string gender)
        {
            var playersFile = gender == "Men" ? MenPlayersFile : WomenPlayersFile;
            var sourcePlayersFile = gender == "Men" ? SourceMenPlayersFile : SourceWomenPlayersFile;

            // Update runtime file
            if (File.Exists(playersFile))
            {
                var json = await File.ReadAllTextAsync(playersFile);
                var teams = JsonSerializer.Deserialize<List<TeamPlayers>>(json);

                foreach (var team in teams)
                {
                    var player = team.Players.FirstOrDefault(p => p.FullName == playerName);
                    if (player != null)
                    {
                        player.ImageFileName = newImageFileName;
                        break;
                    }
                }
                var updatedJson = JsonSerializer.Serialize(teams, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(playersFile, updatedJson);
            }

            // Update source file
            if (File.Exists(sourcePlayersFile))
            {
                var sourceJson = await File.ReadAllTextAsync(sourcePlayersFile);
                var sourceTeams = JsonSerializer.Deserialize<List<TeamPlayers>>(sourceJson);

                foreach (var team in sourceTeams)
                {
                    var player = team.Players.FirstOrDefault(p => p.FullName == playerName);
                    if (player != null)
                    {
                        player.ImageFileName = newImageFileName;
                        break;
                    }
                }
                var updatedSourceJson = JsonSerializer.Serialize(sourceTeams, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(sourcePlayersFile, updatedSourceJson);
            }
        }

        public async Task SavePlayersAsync(List<TeamPlayers> teams, string gender)
        {
            var playersFile = gender == "Men" ? MenPlayersFile : WomenPlayersFile;
            var sourcePlayersFile = gender == "Men" ? SourceMenPlayersFile : SourceWomenPlayersFile;

            var json = JsonSerializer.Serialize(teams, new JsonSerializerOptions { WriteIndented = true });

            // Save to runtime file
            await File.WriteAllTextAsync(playersFile, json);

            // Save to source file
            if (File.Exists(sourcePlayersFile))
            {
                await File.WriteAllTextAsync(sourcePlayersFile, json);
            }
        }

        public async Task UpdatePlayerFavoriteStatus(string playerName, bool isFavorite, string gender)
        {
            var playersFile = gender == "Men" ? MenPlayersFile : WomenPlayersFile;
            var sourcePlayersFile = gender == "Men" ? SourceMenPlayersFile : SourceWomenPlayersFile;

            // Update runtime file
            if (File.Exists(playersFile))
            {
                var json = await File.ReadAllTextAsync(playersFile);
                var teams = JsonSerializer.Deserialize<List<TeamPlayers>>(json);

                foreach (var team in teams)
                {
                    var player = team.Players.FirstOrDefault(p => p.FullName == playerName);
                    if (player != null)
                    {
                        player.IsFavorite = isFavorite;
                        break;
                    }
                }

                var updatedJson = JsonSerializer.Serialize(teams, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(playersFile, updatedJson);
            }

            // Update source file
            if (File.Exists(sourcePlayersFile))
            {
                var sourceJson = await File.ReadAllTextAsync(sourcePlayersFile);
                var sourceTeams = JsonSerializer.Deserialize<List<TeamPlayers>>(sourceJson);

                foreach (var team in sourceTeams)
                {
                    var player = team.Players.FirstOrDefault(p => p.FullName == playerName);
                    if (player != null)
                    {
                        player.IsFavorite = isFavorite;
                        break;
                    }
                }

                var updatedSourceJson = JsonSerializer.Serialize(sourceTeams, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(sourcePlayersFile, updatedSourceJson);
            }
        }

        public Player GetPlayerByName(string playerName, string gender)
        {
            var playersFile = gender == "Men" ? MenPlayersFile : WomenPlayersFile;

            if (File.Exists(playersFile))
            {
                try
                {
                    var json = File.ReadAllText(playersFile);
                    var teams = JsonSerializer.Deserialize<List<TeamPlayers>>(json);

                    foreach (var team in teams)
                    {
                        var player = team.Players.FirstOrDefault(p => p.FullName == playerName);
                        if (player != null)
                        {
                            return player;
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Log the error but don't throw - return null instead
                    Console.WriteLine($"Error loading player {playerName}: {ex.Message}");
                }
            }

            return null;
        }
    }
} 