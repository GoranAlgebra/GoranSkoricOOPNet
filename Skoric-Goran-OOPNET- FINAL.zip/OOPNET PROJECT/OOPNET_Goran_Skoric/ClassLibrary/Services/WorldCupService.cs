using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.IO;
using ClassLibrary.Models;

namespace ClassLibrary.Services
{
    public class WorldCupService
    {
        private readonly HttpClient _httpClient;
        private const string BaseUrl = "https://worldcup-vua.nullbit.hr";

        // Define a base directory for all data files, relative to the executing assembly's location
        private static string BaseDataDirectory => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data");

        // Define gender-specific data directories
        public static string MenDataDirectory => Path.Combine(BaseDataDirectory, "Male");
        public static string WomenDataDirectory => Path.Combine(BaseDataDirectory, "Female");

        // Define full paths for data files
        public static string MenDataFile => Path.Combine(MenDataDirectory, "men_worldcup_data.json");
        public static string WomenDataFile => Path.Combine(WomenDataDirectory, "women_worldcup_data.json");

        public WorldCupService()
        {
            _httpClient = new HttpClient();
            // Ensure data directories exist when the service is instantiated
            Directory.CreateDirectory(MenDataDirectory);
            Directory.CreateDirectory(WomenDataDirectory);
        }

        public async Task<(bool success, string logMessage)> SaveMenWorldCupData()
        {
            string logMessage = "";
            try
            {
                logMessage += "[WorldCupService] Starting to fetch men's World Cup data...\n";
                
                string matchesJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching men's matches...\n";
                    matchesJson = await GetMenMatches();
                    logMessage += $"[WorldCupService] Men's Matches fetched, length: {matchesJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching men's matches: {ex.Message}\n"; throw; }

                string teamsJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching men's teams...\n";
                    teamsJson = await GetMenTeams();
                    logMessage += $"[WorldCupService] Men's Teams fetched, length: {teamsJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching men's teams: {ex.Message}\n"; throw; }

                string teamResultsJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching men's team results...\n";
                    teamResultsJson = await GetMenTeamResults();
                    logMessage += $"[WorldCupService] Men's Team results fetched, length: {teamResultsJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching men's team results: {ex.Message}\n"; throw; }

                string groupResultsJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching men's group results...\n";
                    groupResultsJson = await GetMenGroupResults();
                    logMessage += $"[WorldCupService] Men's Group results fetched, length: {groupResultsJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching men's group results: {ex.Message}\n"; throw; }

                logMessage += "[WorldCupService] Saving all data to file...\n";
                try
                {
                    using (FileStream fs = File.Create(MenDataFile))
                    using (Utf8JsonWriter writer = new Utf8JsonWriter(fs, new JsonWriterOptions { Indented = true }))
                    {
                        writer.WriteStartObject();

                        writer.WritePropertyName("Matches");
                        using (JsonDocument doc = JsonDocument.Parse(matchesJson)) doc.RootElement.WriteTo(writer);

                        writer.WritePropertyName("Teams");
                        using (JsonDocument doc = JsonDocument.Parse(teamsJson)) doc.RootElement.WriteTo(writer);

                        writer.WritePropertyName("TeamResults");
                        using (JsonDocument doc = JsonDocument.Parse(teamResultsJson)) doc.RootElement.WriteTo(writer);

                        writer.WritePropertyName("GroupResults");
                        using (JsonDocument doc = JsonDocument.Parse(groupResultsJson)) doc.RootElement.WriteTo(writer);
                        
                        writer.WriteEndObject();
                    }
                    logMessage += "[WorldCupService] Men's World Cup data saved successfully\n";
                    return (true, logMessage);
                }
                catch (Exception ex)
                {
                    logMessage += $"[WorldCupService] Error during file write or JSON parsing for men's data: {ex.Message}\n";
                    return (false, logMessage);
                }
            }
            catch (Exception ex)
            {
                logMessage += $"[WorldCupService] General error in SaveMenWorldCupData: {ex.Message}\n";
                return (false, logMessage);
            }
        }

        public async Task<(bool success, string logMessage)> SaveWomenWorldCupData()
        {
            string logMessage = "";
            try
            {
                logMessage += "[WorldCupService] Starting to fetch women's World Cup data...\n";
                
                string matchesJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching women's matches...\n";
                    matchesJson = await GetWomenMatches();
                    logMessage += $"[WorldCupService] Women's Matches fetched, length: {matchesJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching women's matches: {ex.Message}\n"; throw; }

                string teamsJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching women's teams...\n";
                    teamsJson = await GetWomenTeams();
                    logMessage += $"[WorldCupService] Women's Teams fetched, length: {teamsJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching women's teams: {ex.Message}\n"; throw; }

                string teamResultsJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching women's team results...\n";
                    teamResultsJson = await GetWomenTeamResults();
                    logMessage += $"[WorldCupService] Women's Team results fetched, length: {teamResultsJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching women's team results: {ex.Message}\n"; throw; }

                string groupResultsJson = "";
                try
                {
                    logMessage += "[WorldCupService] Fetching women's group results...\n";
                    groupResultsJson = await GetWomenGroupResults();
                    logMessage += $"[WorldCupService] Women's Group results fetched, length: {groupResultsJson.Length}\n";
                }
                catch (Exception ex) { logMessage += $"[WorldCupService] Error fetching women's group results: {ex.Message}\n"; throw; }

                logMessage += "[WorldCupService] Saving all data to file...\n";
                try
                {
                    using (FileStream fs = File.Create(WomenDataFile))
                    using (Utf8JsonWriter writer = new Utf8JsonWriter(fs, new JsonWriterOptions { Indented = true }))
                    {
                        writer.WriteStartObject();

                        writer.WritePropertyName("Matches");
                        using (JsonDocument doc = JsonDocument.Parse(matchesJson)) doc.RootElement.WriteTo(writer);

                        writer.WritePropertyName("Teams");
                        using (JsonDocument doc = JsonDocument.Parse(teamsJson)) doc.RootElement.WriteTo(writer);

                        writer.WritePropertyName("TeamResults");
                        using (JsonDocument doc = JsonDocument.Parse(teamResultsJson)) doc.RootElement.WriteTo(writer);

                        writer.WritePropertyName("GroupResults");
                        using (JsonDocument doc = JsonDocument.Parse(groupResultsJson)) doc.RootElement.WriteTo(writer);
                        
                        writer.WriteEndObject();
                    }
                    logMessage += "[WorldCupService] Women's World Cup data saved successfully\n";
                    return (true, logMessage);
                }
                catch (Exception ex)
                {
                    logMessage += $"[WorldCupService] Error during file write or JSON parsing for women's data: {ex.Message}\n";
                    return (false, logMessage);
                }
            }
            catch (Exception ex)
            {
                logMessage += $"[WorldCupService] General error in SaveWomenWorldCupData: {ex.Message}\n";
                return (false, logMessage);
            }
        }

        private async Task<string> GetMenMatches()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/men/matches");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetMenTeams()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/men/teams");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetMenTeamResults()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/men/teams/results");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetMenGroupResults()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/men/teams/group_results");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetWomenMatches()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/women/matches");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetWomenTeams()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/women/teams");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetWomenTeamResults()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/women/teams/results");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        private async Task<string> GetWomenGroupResults()
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/women/teams/group_results");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<JsonElement> LoadMenWorldCupDataJsonElement()
        {
            if (!File.Exists(MenDataFile))
            {
                await SaveMenWorldCupData();
            }
            string json = await File.ReadAllTextAsync(MenDataFile);
            using (JsonDocument doc = JsonDocument.Parse(json))
            {
                return doc.RootElement.Clone();
            }
        }

        public async Task<JsonElement> LoadWomenWorldCupDataJsonElement()
        {
            var filePath = WomenDataFile;
            if (!File.Exists(filePath))
                throw new FileNotFoundException($"Women's World Cup data file not found at: {filePath}");
            
            using (var stream = File.OpenRead(filePath))
            {
                var doc = await JsonDocument.ParseAsync(stream);
                return doc.RootElement.Clone();
            }
        }

        public async Task<List<MatchModel>> GetMatchesByCountryAsync(string fifaCode, string gender)
        {
            var dataFile = gender.Equals("Men", StringComparison.OrdinalIgnoreCase) ? MenDataFile : WomenDataFile;
            if (!File.Exists(dataFile))
                return new List<MatchModel>();

            var json = await File.ReadAllTextAsync(dataFile);
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var matches = JsonSerializer.Deserialize<List<MatchModel>>(JsonDocument.Parse(json).RootElement.GetProperty("Matches").GetRawText(), options);

            return matches.Where(m => m.HomeTeam.Code == fifaCode || m.AwayTeam.Code == fifaCode).ToList();
        }
    }
} 