using System.Collections.Generic;

namespace ClassLibrary.Models
{
    public class TeamPlayers
    {
        public string TeamName { get; set; }
        public string FifaCode { get; set; }
        public List<Player> Players { get; set; } = new List<Player>();
    }
} 