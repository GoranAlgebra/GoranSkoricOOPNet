namespace ClassLibrary.Models
{
    public class MatchRanking
    {
        public string Location { get; set; }
        public string Venue { get; set; }
        public int Visitors { get; set; }
        public string HomeTeam { get; set; }
        public string AwayTeam { get; set; }
        public int HomeTeamScore { get; set; }
        public int AwayTeamScore { get; set; }
        public DateTime MatchDate { get; set; }
        public string Competition { get; set; }
        public string Season { get; set; }
        public string Stadium { get; set; }
        public string Referee { get; set; }
        public string MatchStatus { get; set; }
        public int MatchWeek { get; set; }
        public string MatchDay { get; set; }
        public string MatchTime { get; set; }
        public string Weather { get; set; }
        public int Temperature { get; set; }
        public string PitchCondition { get; set; }
        public double Attendance { get; set; }
        public string HomeTeamFormation { get; set; }
        public string AwayTeamFormation { get; set; }
    }
} 