using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ClassLibrary.Models
{
    public class WorldCupDataModel
    {
        [JsonPropertyName("Matches")]
        public List<MatchModel> Matches { get; set; }

        [JsonPropertyName("Teams")]
        public List<TeamDataModel> Teams { get; set; }

        [JsonPropertyName("TeamResults")]
        public List<object> TeamResults { get; set; } // Can be more specific if needed

        [JsonPropertyName("GroupResults")]
        public List<object> GroupResults { get; set; } // Can be more specific if needed
    }

    public class MatchModel
    {
        [JsonPropertyName("venue")]
        public string Venue { get; set; }

        [JsonPropertyName("location")]
        public string Location { get; set; }

        [JsonPropertyName("status")]
        public string Status { get; set; }

        [JsonPropertyName("time")]
        public string Time { get; set; }

        [JsonPropertyName("fifa_id")]
        public string FifaId { get; set; }

        [JsonPropertyName("weather")]
        public WeatherModel Weather { get; set; }

        [JsonPropertyName("attendance")]
        public string Attendance { get; set; }

        [JsonPropertyName("officials")]
        public List<string> Officials { get; set; }

        [JsonPropertyName("stage_name")]
        public string StageName { get; set; }

        [JsonPropertyName("home_team_country")]
        public string HomeTeamCountry { get; set; }

        [JsonPropertyName("away_team_country")]
        public string AwayTeamCountry { get; set; }

        [JsonPropertyName("datetime")]
        public string Datetime { get; set; }

        [JsonPropertyName("winner")]
        public string Winner { get; set; }

        [JsonPropertyName("winner_code")]
        public string WinnerCode { get; set; }

        [JsonPropertyName("home_team")]
        public TeamDataModel HomeTeam { get; set; }

        [JsonPropertyName("away_team")]
        public TeamDataModel AwayTeam { get; set; }

        [JsonPropertyName("home_team_events")]
        public List<EventModel> HomeTeamEvents { get; set; }

        [JsonPropertyName("away_team_events")]
        public List<EventModel> AwayTeamEvents { get; set; }

        [JsonPropertyName("home_team_statistics")]
        public TeamStatisticsModel HomeTeamStatistics { get; set; }

        [JsonPropertyName("away_team_statistics")]
        public TeamStatisticsModel AwayTeamStatistics { get; set; }
    }

    public class TeamDataModel
    {
        [JsonPropertyName("country")]
        public string Country { get; set; }

        [JsonPropertyName("code")]
        public string Code { get; set; }

        [JsonPropertyName("goals")]
        public int Goals { get; set; }

        [JsonPropertyName("penalties")]
        public int Penalties { get; set; }
    }

    public class TeamStatisticsModel
    {
        [JsonPropertyName("country")]
        public string Country { get; set; }

        [JsonPropertyName("attempts_on_goal")]
        public int? AttemptsOnGoal { get; set; }

        [JsonPropertyName("on_target")]
        public int? OnTarget { get; set; }

        [JsonPropertyName("off_target")]
        public int? OffTarget { get; set; }

        [JsonPropertyName("blocked")]
        public int? Blocked { get; set; }

        [JsonPropertyName("woodwork")]
        public int? Woodwork { get; set; }

        [JsonPropertyName("corners")]
        public int? Corners { get; set; }

        [JsonPropertyName("offsides")]
        public int? Offsides { get; set; }

        [JsonPropertyName("ball_possession")]
        public int? BallPossession { get; set; }

        [JsonPropertyName("pass_accuracy")]
        public int? PassAccuracy { get; set; }

        [JsonPropertyName("num_passes")]
        public int? NumPasses { get; set; }

        [JsonPropertyName("passes_completed")]
        public int? PassesCompleted { get; set; }

        [JsonPropertyName("distance_covered")]
        public int? DistanceCovered { get; set; }

        [JsonPropertyName("balls_recovered")]
        public int? BallsRecovered { get; set; }

        [JsonPropertyName("tackles")]
        public int? Tackles { get; set; }

        [JsonPropertyName("clearances")]
        public int? Clearances { get; set; }

        [JsonPropertyName("yellow_cards")]
        public int? YellowCards { get; set; }

        [JsonPropertyName("red_cards")]
        public int? RedCards { get; set; }

        [JsonPropertyName("fouls_committed")]
        public int? FoulsCommitted { get; set; }

        [JsonPropertyName("tactics")]
        public string Tactics { get; set; }

        [JsonPropertyName("starting_eleven")]
        public List<PlayerRawDataModel> StartingEleven { get; set; }

        [JsonPropertyName("substitutes")]
        public List<PlayerRawDataModel> Substitutes { get; set; }
    }

    public class PlayerRawDataModel
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("captain")]
        public bool Captain { get; set; }

        [JsonPropertyName("shirt_number")]
        public int ShirtNumber { get; set; }

        [JsonPropertyName("position")]
        public string Position { get; set; }

        [JsonPropertyName("image_file_name")]
        public string? ImageFileName { get; set; }
    }

    public class EventModel
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("type_of_event")]
        public string TypeOfEvent { get; set; }

        [JsonPropertyName("player")]
        public string PlayerName { get; set; }

        [JsonPropertyName("time")]
        public string Time { get; set; }
    }

    public class WeatherModel
    {
        [JsonPropertyName("humidity")]
        public string Humidity { get; set; }

        [JsonPropertyName("temp_celsius")]
        public string TempCelsius { get; set; }

        [JsonPropertyName("temp_farenheit")]
        public string TempFarenheit { get; set; }

        [JsonPropertyName("wind_speed")]
        public string WindSpeed { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }
    }
} 