namespace ClassLibrary.Models
{
    public class FavoriteTeam
    {
        public string Name { get; set; }
        public string FifaCode { get; set; }
    }
} 