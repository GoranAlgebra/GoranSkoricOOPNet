using System.Text.Json.Serialization;

namespace ClassLibrary.Models
{
    public class Player
    {
        public string Name { get; set; }
        public string FullName { get; set; }
        public int ShirtNumber { get; set; }
        public string Position { get; set; }
        public bool IsCaptain { get; set; }
        public bool IsFavorite { get; set; } = false; // Used to show a ★ star in UI
        public string ImageFileName { get; set; }

        // Ranking fields
        public int Goals { get; set; }
        public int GoalsScored { get; set; }
        public int YellowCards { get; set; }
        public int Appearances { get; set; }

        [JsonIgnore]
        public int RedCards { get; set; }
        [JsonIgnore]
        public int Assists { get; set; }
        [JsonIgnore]
        public int MinutesPlayed { get; set; }
        [JsonIgnore]
        public int PassesCompleted { get; set; }
        [JsonIgnore]
        public int PassesAttempted { get; set; }
        [JsonIgnore]
        public int ShotsOnTarget { get; set; }
        [JsonIgnore]
        public int ShotsOffTarget { get; set; }
        [JsonIgnore]
        public int Saves { get; set; }
        [JsonIgnore]
        public int FoulsCommitted { get; set; }
        [JsonIgnore]
        public int FoulsDrawn { get; set; }
        [JsonIgnore]
        public int Offsides { get; set; }
        [JsonIgnore]
        public int Tackles { get; set; }
        [JsonIgnore]
        public int Interceptions { get; set; }
        [JsonIgnore]
        public int Clearances { get; set; }
        [JsonIgnore]
        public int Blocks { get; set; }
        [JsonIgnore]
        public int DribblesCompleted { get; set; }
        [JsonIgnore]
        public int DribblesAttempted { get; set; }
        [JsonIgnore]
        public int CrossesCompleted { get; set; }
        [JsonIgnore]
        public int CrossesAttempted { get; set; }
        [JsonIgnore]
        public int LongBallsCompleted { get; set; }
        [JsonIgnore]
        public int LongBallsAttempted { get; set; }
        [JsonIgnore]
        public int ThroughBallsCompleted { get; set; }
        [JsonIgnore]
        public int ThroughBallsAttempted { get; set; }
        [JsonIgnore]
        public int AerialDuelsWon { get; set; }
        [JsonIgnore]
        public int AerialDuelsLost { get; set; }
        [JsonIgnore]
        public int GroundDuelsWon { get; set; }
        [JsonIgnore]
        public int GroundDuelsLost { get; set; }
        [JsonIgnore]
        public int Recoveries { get; set; }
        [JsonIgnore]
        public int PossessionsWon { get; set; }
        [JsonIgnore]
        public int PossessionsLost { get; set; }
        [JsonIgnore]
        public int KeyPasses { get; set; }
        [JsonIgnore]
        public int ChancesCreated { get; set; }
        [JsonIgnore]
        public int BigChancesCreated { get; set; }
        [JsonIgnore]
        public int BigChancesMissed { get; set; }
        [JsonIgnore]
        public int PenaltiesScored { get; set; }
        [JsonIgnore]
        public int PenaltiesMissed { get; set; }
        [JsonIgnore]
        public int PenaltiesSaved { get; set; }
        [JsonIgnore]
        public int PenaltiesConceded { get; set; }
        [JsonIgnore]
        public int OwnGoals { get; set; }
        [JsonIgnore]
        public int ErrorsLeadingToGoal { get; set; }
        [JsonIgnore]
        public int ErrorsLeadingToShot { get; set; }
        [JsonIgnore]
        public int SavesInsideBox { get; set; }
        [JsonIgnore]
        public int SavesOutsideBox { get; set; }
        [JsonIgnore]
        public int Punches { get; set; }
        [JsonIgnore]
        public int HighClaims { get; set; }
        [JsonIgnore]
        public int Catches { get; set; }
        [JsonIgnore]
        public int SweeperClearances { get; set; }
        [JsonIgnore]
        public int ThrowOuts { get; set; }
        [JsonIgnore]
        public int GoalKicks { get; set; }
        [JsonIgnore]
        public int PassesPerGame { get; set; }
        [JsonIgnore]
        public int BigChancesCreatedPerGame { get; set; }
        [JsonIgnore]
        public int ManOfTheMatch { get; set; }
        [JsonIgnore]
        public double Rating { get; set; }
    }
}