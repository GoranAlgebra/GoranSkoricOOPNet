﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary.Models;
using System.IO;
using System.Reflection;
using ClassLibrary.Helpers;
using ClassLibrary.Services;

namespace WinFormsApp
{
    public partial class PlayerDetailsForm : Form
    {
        public event Action PlayerUpdated;
        private readonly Player _player;
        private readonly string _gender;
        private readonly PlayerDataService _playerDataService;

        public PlayerDetailsForm()
        {
            InitializeComponent();
            _playerDataService = new PlayerDataService();
            BtnChangePicture.Click += BtnChangePicture_Click;
        }

        public PlayerDetailsForm(Player player, string gender) : this()
        {
            _player = player;
            _gender = gender;
            
            // Reload the player data from JSON to get the most up-to-date information
            var updatedPlayer = _playerDataService.GetPlayerByName(player.FullName, gender);
            if (updatedPlayer != null)
            {
                _player = updatedPlayer;
            }
            
            playerCardExtended1.SetPlayerDetails(_player);
            LoadPlayerImage(_player.ImageFileName);
        }

        private async void BtnChangePicture_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Step 1: Save image using ImageHelper to the correct location
                        string selectedImagePath = openFileDialog.FileName;
                        string destFileName = ImageHelper.SaveImageFromPath(selectedImagePath, _player.FullName);

                        if (destFileName == null)
                        {
                            MessageBox.Show("Failed to save image to the shared location.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // Step 2: Update the current player instance (the one displayed in UI)
                        _player.ImageFileName = destFileName;

                        // Step 3: Update the JSON files using the existing method
                        await _playerDataService.UpdatePlayerImage(_player.FullName, destFileName, _gender);
                        
                        // Step 4: Refresh the UI
                        LoadPlayerImage(destFileName);
                        MessageBox.Show("Picture successfully added and saved to JSON.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        PlayerUpdated?.Invoke();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error updating player image: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void LoadPlayerImage(string imageFileName)
        {
            string imagePath = ImageHelper.GetPlayerImagePath(imageFileName);

            try
            {
                using (var bmpTemp = new Bitmap(imagePath))
                {
                    PbPlayerDetails.Image = new Bitmap(bmpTemp);
                }
            }
            catch (Exception ex)
            {
                // If loading fails, it indicates an issue with the image file itself (e.g., corrupted, missing despite path).
                // For robustness, we can set the image to null or a clear placeholder to avoid crashing.
                PbPlayerDetails.Image = null; // Or load a specific error placeholder image
                MessageBox.Show($"Error loading player image from {imagePath}: {ex.Message}", "Image Loading Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FlpPlayerDetails_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
