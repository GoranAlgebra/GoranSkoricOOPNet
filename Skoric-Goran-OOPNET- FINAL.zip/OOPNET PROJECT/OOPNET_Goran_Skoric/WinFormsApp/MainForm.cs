﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary.Services;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.Json;
using ClassLibrary.Models;
using System.Text;
using System.Drawing;
using System.Drawing.Printing;

namespace WinFormsApp
{
    // Main form for the application
    public partial class MainForm : Form
    {
        // Current language and gender settings
        private string? currentLanguage;
        private string? currentGender;
        // Indicates if the app is loading data
        private bool isLoading = false;
        // Services for data, world cup, and rankings
        private readonly WorldCupService _worldCupService;
        private readonly PlayerDataService _playerDataService;
        private readonly RankingService _rankingService;
        // Lists for teams and printing
        private List<dynamic>? _teams;
        private List<dynamic>? _sortedTeams;
        private PrintDocument printDocument = new PrintDocument();
        private List<DataGridView> dgvToPrintList = new List<DataGridView>();
        private int currentDgvIndex;
        private int printRowIndex;

        // Constructor: initializes services and sets up UI
        public MainForm()
        {
            InitializeComponent();
            _worldCupService = new WorldCupService();
            _playerDataService = new PlayerDataService();
            _rankingService = new RankingService();
            InitializeForm(); // Load initial data
            SetupSettingsTab(); // Setup settings tab controls
            SetupFavoritesTab(); // Setup favorites tab controls
            SetupRankingsTab(); // Setup rankings tab controls

            // Enable drag-n-drop for fav players
            FlpFavoritePlayers.AllowDrop = true;
            FlpFavoritePlayers.DragEnter += FlpFavoritePlayers_DragEnter;
            FlpFavoritePlayers.DragDrop += FlpFavoritePlayers_DragDrop;

            // Enable drag-n-drop for all players
            FlpPlayersDisplay.AllowDrop = true;
            FlpPlayersDisplay.DragEnter += FlpPlayersDisplay_DragEnter;
            FlpPlayersDisplay.DragDrop += FlpPlayersDisplay_DragDrop;

            // Hide loading label by default
            LbLoading.Visible = false;

            // Confirm before closing the form
            this.FormClosing += MainForm_FormClosing;
        }

        // Confirm exit when closing the form
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to quit the application?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2
            );
            if (result != DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        // Handle keyboard shortcuts (ESC to close)
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                // Simulate closing the form (triggers FormClosing event)
                this.Close();
                return true; // Handled
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        // Setup controls and events for the settings tab
        private void SetupSettingsTab()
        {
            // Wire up settings controls
            ConfirmBtn.Click += SettingsConfirmBtn_Click;
            CancelBtn.Click += SettingsCancelBtn_Click;

            // Set up ComboBoxes
            LanguageCb.Items.Clear();
            GenderCb.Items.Clear();

            LanguageCb.Items.AddRange(new object[] { "English", "Croatian" });
            GenderCb.Items.AddRange(new object[] { "Men", "Women" });
        }

        // Setup controls and events for the favorites tab
        private void SetupFavoritesTab()
        {
            BtnSaveFavTeam.Click += BtnSaveFavTeam_Click;
            SaveFavAndImg.Click += SaveFavAndImg_Click;
            BtnSaveTeamPlayers.Click += BtnShowTeamPlayers_Click;

            // Subscribe to player selection events
            FlpPlayersDisplay.ControlAdded += (s, e) => SubscribeToPlayerSelection(e.Control);
            FlpFavoritePlayers.ControlAdded += (s, e) => SubscribeToPlayerSelection(e.Control);
        }

        // Setup controls and events for the rankings tab
        private void SetupRankingsTab()
        {
            BtnPlayerRankingsGoals.Click += BtnPlayerRankingsGoals_Click;
            BtnShowRankingsYC.Click += BtnShowRankingsYC_Click;
            BtnShowMatchRanking.Click += BtnShowMatchRanking_Click;
            BtnPrint.Click += BtnPrint_Click;
            printDocument.PrintPage += printDocument_PrintPage;

            // Configure DataGridView for player rankings
            ConfigurePlayerRankingsDataGridView();

            // ^^^ match rankings
            ConfigureMatchRankingsDataGridView();
        }

        private void ConfigurePlayerRankingsDataGridView()
        {
            DTGPlayerRankings.AutoGenerateColumns = false;
            DTGPlayerRankings.AllowUserToAddRows = false;
            DTGPlayerRankings.AllowUserToDeleteRows = false;
            DTGPlayerRankings.ReadOnly = true;
            DTGPlayerRankings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DTGPlayerRankings.RowTemplate.Height = 80; // Make rows taller for player cards

            // Clear existing columns
            DTGPlayerRankings.Columns.Clear();

            // Add columns for player ranking display
            DTGPlayerRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Rank",
                HeaderText = "Rank",
                DataPropertyName = "Rank",
                Width = 50
            });

            DTGPlayerRankings.Columns.Add(new DataGridViewImageColumn
            {
                Name = "PlayerImage",
                HeaderText = "Player",
                DataPropertyName = "PlayerImage",
                Width = 60,
                ImageLayout = DataGridViewImageCellLayout.Zoom
            });

            DTGPlayerRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "FullName",
                HeaderText = "Player Name",
                DataPropertyName = "FullName",
                Width = 150
            });

            DTGPlayerRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Appearances",
                HeaderText = "Appearances",
                DataPropertyName = "Appearances",
                Width = 80
            });

            DTGPlayerRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "GoalsScored",
                HeaderText = "Goals",
                DataPropertyName = "GoalsScored",
                Width = 60
            });

            DTGPlayerRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "YellowCards",
                HeaderText = "Yellow Cards",
                DataPropertyName = "YellowCards",
                Width = 80
            });
        }

        private void ConfigureMatchRankingsDataGridView()
        {
            DTGMatchRankings.AutoGenerateColumns = false;
            DTGMatchRankings.AllowUserToAddRows = false;
            DTGMatchRankings.AllowUserToDeleteRows = false;
            DTGMatchRankings.ReadOnly = true;
            DTGMatchRankings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Clear existing columns
            DTGMatchRankings.Columns.Clear();

            // Add columns for match ranking display
            DTGMatchRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Rank",
                HeaderText = "Rank",
                DataPropertyName = "Rank",
                Width = 50
            });

            DTGMatchRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Location",
                HeaderText = "Location",
                DataPropertyName = "Location",
                Width = 120
            });

            DTGMatchRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Venue",
                HeaderText = "Venue",
                DataPropertyName = "Venue",
                Width = 150
            });

            DTGMatchRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "HomeTeam",
                HeaderText = "Home Team",
                DataPropertyName = "HomeTeam",
                Width = 120
            });

            DTGMatchRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "AwayTeam",
                HeaderText = "Away Team",
                DataPropertyName = "AwayTeam",
                Width = 120
            });

            DTGMatchRankings.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Attendance",
                HeaderText = "Visitors",
                DataPropertyName = "Visitors",
                Width = 100
            });
        }

        // Subscribe to player selection event for a control
        private void SubscribeToPlayerSelection(Control control)
        {
            if (control is PlayerControl playerControl)
            {
                playerControl.PlayerSelected += PlayerControl_Selected;
            }
        }

        // Handle when a player is selected in the UI
        private void PlayerControl_Selected(object sender, PlayerControl selectedControl)
        {
            // Only allow multi-select with Ctrl
            if (!Control.ModifierKeys.HasFlag(Keys.Control))
            {
                // Deselect all other player controls
                foreach (Control control in FlpPlayersDisplay.Controls)
                {
                    if (control is PlayerControl playerControl && playerControl != selectedControl)
                    {
                        playerControl.Deselect();
                    }
                }
                foreach (Control control in FlpFavoritePlayers.Controls)
                {
                    if (control is PlayerControl playerControl && playerControl != selectedControl)
                    {
                        playerControl.Deselect();
                    }
                }
            }
            // Get all currently selected players
            var selectedPlayers = GetSelectedPlayers();
        }

        // Get a list of all selected players from both displays
        private List<Player> GetSelectedPlayers()
        {
            var selectedPlayers = new List<Player>();

            // Check main display
            foreach (Control control in FlpPlayersDisplay.Controls)
            {
                if (control is PlayerControl playerControl && playerControl.IsSelected)
                {
                    selectedPlayers.Add(playerControl.PlayerData);
                }
            }

            // Check favorites
            foreach (Control control in FlpFavoritePlayers.Controls)
            {
                if (control is PlayerControl playerControl && playerControl.IsSelected)
                {
                    selectedPlayers.Add(playerControl.PlayerData);
                }
            }

            return selectedPlayers;
        }

        // Handle confirming and saving settings
        private async void SettingsConfirmBtn_Click(object sender, EventArgs e)
        {
            if (isLoading) return;

            // Show confirmation dialog
            var result = MessageBox.Show(
                "Are you sure you want to apply these settings?",
                "Confirm Settings",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1
            );

            // If user cancels (No or Esc), do not proceed
            if (result != DialogResult.Yes)
                return;

            try
            {
                SetLoadingState(true);

                // Save new settings to file
                await Program.SaveSettingsAsync(
                    LanguageCb.SelectedItem?.ToString() ?? "English",
                    GenderCb.SelectedItem?.ToString() ?? "Men"
                );

                // Update current settings in memory
                currentLanguage = LanguageCb.SelectedItem?.ToString();
                currentGender = GenderCb.SelectedItem?.ToString();

                // Load player data and generate rankings for selected gender
                if (currentGender == "Men")
                {
                    await _worldCupService.SaveMenWorldCupData();
                    var (success, logMessage) = await _playerDataService.SaveTeamPlayers("Men");
                    if (!success)
                    {
                        MessageBox.Show(logMessage, "Error Saving Team Players", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    await _playerDataService.SavePlayerRankings("Men");
                    await _playerDataService.SaveMatchVisitorRankings("Men");
                    MessageBox.Show("Men's World Cup data, player information, and rankings loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    await _worldCupService.SaveWomenWorldCupData();
                    var (success, logMessage) = await _playerDataService.SaveTeamPlayers("Women");
                    if (!success)
                    {
                        MessageBox.Show(logMessage, "Error Saving Team Players", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    await _playerDataService.SavePlayerRankings("Women");
                    await _playerDataService.SaveMatchVisitorRankings("Women");
                    MessageBox.Show("Women's World Cup data, player information, and rankings loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                await LoadDataAsync();

                // Synchronize favorites for the new gender
                await SynchronizeFavoritesOnStartup();

                // Clear player rankings and auto-load match rankings for the new gender
                DTGPlayerRankings.DataSource = null;
                ShowMatchRankings();

                ApplyLanguage();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings and loading data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void SettingsCancelBtn_Click(object sender, EventArgs e)
        {
            // Reset ComboBoxes to current settings
            if (currentLanguage != null)
                LanguageCb.SelectedItem = currentLanguage;
            if (currentGender != null)
                GenderCb.SelectedItem = currentGender;
        }

        private async void InitializeForm()
        {
            try
            {
                SetLoadingState(true);
                LbLoading.Text = "Loading settings...";

                await LoadSettingsAsync();
                UpdateSettingsControls();

                LbLoading.Text = "Loading World Cup data...";
                await LoadWorldCupDataOnStartup();

                LbLoading.Text = "Loading application data...";
                await LoadDataAsync();

                LbLoading.Text = "Synchronizing favorites...";
                await SynchronizeFavoritesOnStartup();

                LbLoading.Text = "Loading match rankings...";
                ShowMatchRankings();

                ApplyLanguage();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during MainForm initialization: {ex.Message}", "MainForm Init Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private async Task LoadSettingsAsync()
        {
            var settings = await Program.LoadSettingsAsync();
            currentLanguage = settings.language;
            currentGender = settings.gender;
        }

        private void UpdateSettingsControls()
        {
            // Update ComboBoxes with current settings
            if (currentLanguage != null)
                LanguageCb.SelectedItem = currentLanguage;
            if (currentGender != null)
                GenderCb.SelectedItem = currentGender;
        }

        private void SetLoadingState(bool loading)
        {
            isLoading = loading;
            // Disable all interactive controls while loading
            foreach (Control control in this.Controls)
            {
                if (control is Button || control is ComboBox || control is TextBox)
                {
                    control.Enabled = !loading;
                }
            }

            // Show/hide loading indicator
            if (loading)
            {
                LbLoading.Visible = true;
                LbLoading.Text = "Loading...";
                LbLoading.BringToFront();
            }
            else
            {
                LbLoading.Visible = false;
            }
        }

        protected async Task LoadDataAsync()
        {
            SetLoadingState(true);
            try
            {
                FlpFavoritePlayers.Controls.Clear();
                FlpPlayersDisplay.Controls.Clear();

                // Load favorite players first
                List<Player> favoritePlayers = new List<Player>();
                string favoritePlayersPath = GetFavoritePlayersFilePath();
                if (File.Exists(favoritePlayersPath))
                {
                    try
                    {
                        string json = await File.ReadAllTextAsync(favoritePlayersPath);
                        favoritePlayers = JsonSerializer.Deserialize<List<Player>>(json);

                        foreach (var player in favoritePlayers)
                        {
                            FlpFavoritePlayers.Controls.Add(new PlayerControl(player));
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error loading favorite players: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                // Load and display teams for dropdowns
                await LoadTeamsForComboBox();

                // Automatically load favorite team's players if available
                await LoadFavoriteTeamPlayers();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"General error during LoadDataAsync: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private async Task LoadFavoriteTeamPlayers()
        {
            try
            {
                // Check if favorite team exists
                string favoriteTeamPath = GetFavoriteTeamFilePath();
                if (!File.Exists(favoriteTeamPath))
                {
                    return; // No favorite team set, so don't load any players
                }

                // Read favorite team
                string favoriteTeamContent = await File.ReadAllTextAsync(favoriteTeamPath);
                var match = System.Text.RegularExpressions.Regex.Match(favoriteTeamContent, @"\((.+)\)");
                if (!match.Success)
                {
                    return; // Could not parse favorite team
                }

                string favTeamFifaCode = match.Groups[1].Value;

                // Check if player data exists
                string playersFilePath = currentGender == "Men"
                    ? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "Male", "men_players.json")
                    : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "Female", "women_players.json");

                if (!File.Exists(playersFilePath))
                {
                    return; // No player data available yet
                }

                // Load all teams and players
                var teams = await _playerDataService.LoadTeamPlayers(currentGender);
                var favoriteTeam = teams.FirstOrDefault(t => t.FifaCode == favTeamFifaCode);

                if (favoriteTeam == null)
                {
                    return; // Favorite team not found in loaded data
                }

                // Get favorite players to check against
                List<Player> favoritePlayers = new List<Player>();
                string favoritePlayersPath = GetFavoritePlayersFilePath();
                if (File.Exists(favoritePlayersPath))
                {
                    string json = await File.ReadAllTextAsync(favoritePlayersPath);
                    favoritePlayers = JsonSerializer.Deserialize<List<Player>>(json);
                }
                HashSet<string> favoritePlayerNames = new HashSet<string>(favoritePlayers.Select(p => p.Name));

                // Display favorite team's players, excluding those already in favorites
                foreach (var player in favoriteTeam.Players)
                {
                    if (!favoritePlayerNames.Contains(player.Name))
                    {
                        var playerControl = new PlayerControl(player);
                        FlpPlayersDisplay.Controls.Add(playerControl);
                    }
                }
            }
            catch (Exception ex)
            {
                // Don't show error message for this, as it's just an auto-load feature
                Console.WriteLine($"Auto-loading favorite team players failed: {ex.Message}");
            }
        }

        private string GetFavoritePlayersFilePath()
        {
            string genderFolder = currentGender == "Men" ? "Male" : "Female";
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", genderFolder, $"{currentGender.ToLower()}_favorite_players.json");
        }

        private string GetFavoriteTeamFilePath()
        {
            string genderFolder = currentGender == "Men" ? "Male" : "Female";
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", genderFolder, $"{currentGender.ToLower()}_favorite_team.txt");
        }

        private async void BtnLoadPlayers_Click(object sender, EventArgs e)
        {
            if (isLoading) return;

            try
            {
                SetLoadingState(true);

                if (currentGender == "Men")
                {
                    await _worldCupService.SaveMenWorldCupData();
                    var (success, logMessage) = await _playerDataService.SaveTeamPlayers("Men");
                    if (!success)
                    {
                        MessageBox.Show(logMessage, "Error Saving Team Players", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    MessageBox.Show(logMessage, "Team Players Save Log", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await _playerDataService.SavePlayerRankings("Men");
                    await _playerDataService.SaveMatchVisitorRankings("Men");
                    MessageBox.Show("Men's World Cup data, player information, and rankings loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    await _worldCupService.SaveWomenWorldCupData();
                    var (success, logMessage) = await _playerDataService.SaveTeamPlayers("Women");
                    if (!success)
                    {
                        MessageBox.Show(logMessage, "Error Saving Team Players", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    MessageBox.Show(logMessage, "Team Players Save Log", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await _playerDataService.SavePlayerRankings("Women");
                    await _playerDataService.SaveMatchVisitorRankings("Women");
                    MessageBox.Show("Women's World Cup data, player information, and rankings loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                // After loading/saving data, refresh team comboboxes to reflect potentially new data or ensure they are populated.
                await LoadTeamsForComboBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading World Cup data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private async void BtnSaveFavTeam_Click(object sender, EventArgs e)
        {
            if (isLoading) return;

            if (CbTeams.SelectedItem == null)
            {
                MessageBox.Show("Please select a team first.", "No Team Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                SetLoadingState(true);
                string selectedTeamName = ((dynamic)CbTeams.SelectedItem).Name;
                string selectedFifaCode = ((dynamic)CbTeams.SelectedItem).FifaCode;

                FavoriteTeam favoriteTeam = new FavoriteTeam
                {
                    Name = selectedTeamName,
                    FifaCode = selectedFifaCode
                };

                string json = JsonSerializer.Serialize(favoriteTeam, new JsonSerializerOptions { WriteIndented = true });
                string favoriteTeamPath = GetFavoriteTeamFilePath();
                await File.WriteAllTextAsync(favoriteTeamPath, json);
                MessageBox.Show($"Favorite team \'{selectedTeamName}\' saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving favorite team: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private async void SaveFavAndImg_Click(object sender, EventArgs e)
        {
            if (isLoading) return;

            try
            {
                SetLoadingState(true);

                List<Player> favoritePlayers = new List<Player>();
                foreach (Control control in FlpFavoritePlayers.Controls)
                {
                    if (control is PlayerControl playerControl)
                    {
                        favoritePlayers.Add(playerControl.PlayerData);
                    }
                }

                // Define both runtime and source file paths
                string genderFolder = currentGender == "Men" ? "Male" : "Female";
                string runtimeFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", genderFolder, $"{currentGender.ToLower()}_favorite_players.json");
                string sourceFilePath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\ClassLibrary\Data", genderFolder, $"{currentGender.ToLower()}_favorite_players.json"));

                // Ensure directories exist
                Directory.CreateDirectory(Path.GetDirectoryName(runtimeFilePath));
                Directory.CreateDirectory(Path.GetDirectoryName(sourceFilePath));

                // Serialize the favorite players
                string json = JsonSerializer.Serialize(favoritePlayers, new JsonSerializerOptions { WriteIndented = true });

                // Save to runtime file
                await File.WriteAllTextAsync(runtimeFilePath, json);

                // Save to source file
                await File.WriteAllTextAsync(sourceFilePath, json);

                // Also update the IsFavorite property in the main players file
                await UpdateFavoriteStatusInMainPlayersFile(favoritePlayers);

                MessageBox.Show("Favorite players saved successfully to both runtime and source files!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving favorite players: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private async Task UpdateFavoriteStatusInMainPlayersFile(List<Player> favoritePlayers)
        {
            try
            {
                // Define file paths for main players file
                string genderFolder = currentGender == "Men" ? "Male" : "Female";
                string runtimePlayersFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", genderFolder, $"{currentGender.ToLower()}_players.json");
                string sourcePlayersFile = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\ClassLibrary\Data", genderFolder, $"{currentGender.ToLower()}_players.json"));

                // Create a set of favorite player names for quick lookup
                HashSet<string> favoritePlayerNames = new HashSet<string>(favoritePlayers.Select(p => p.Name));

                // Load current teams and players
                var teams = await _playerDataService.LoadTeamPlayers(currentGender);

                // Update IsFavorite status for all players
                foreach (var team in teams)
                {
                    foreach (var player in team.Players)
                    {
                        player.IsFavorite = favoritePlayerNames.Contains(player.Name);
                    }
                }

                // Save updated teams back to both runtime and source files
                string updatedJson = JsonSerializer.Serialize(teams, new JsonSerializerOptions { WriteIndented = true });

                // Ensure directories exist
                Directory.CreateDirectory(Path.GetDirectoryName(runtimePlayersFile));
                Directory.CreateDirectory(Path.GetDirectoryName(sourcePlayersFile));

                // Save to runtime file
                await File.WriteAllTextAsync(runtimePlayersFile, updatedJson);

                // Save to source file
                await File.WriteAllTextAsync(sourcePlayersFile, updatedJson);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating favorite status in main players file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void BtnShowTeamPlayers_Click(object sender, EventArgs e)
        {
            if (CbTeamforPlayers.SelectedItem == null)
            {
                MessageBox.Show("Please select a team.", "No Team Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                SetLoadingState(true);

                // Extract team details from the selected item
                var selectedItem = (dynamic)CbTeamforPlayers.SelectedItem;
                string country = selectedItem.Name;
                string fifaCode = selectedItem.FifaCode;

                // Load player rankings
                var rankedPlayers = await _rankingService.GetPlayerRankings(fifaCode, currentGender);

                // Clear existing player controls
                FlpPlayersDisplay.Controls.Clear();

                // Get favorite players to check against
                List<Player> favoritePlayers = new List<Player>();
                string favoritePlayersPath = GetFavoritePlayersFilePath();
                if (File.Exists(favoritePlayersPath))
                {
                    string json = await File.ReadAllTextAsync(favoritePlayersPath);
                    favoritePlayers = JsonSerializer.Deserialize<List<Player>>(json);
                }
                HashSet<string> favoritePlayerNames = new HashSet<string>(favoritePlayers.Select(p => p.Name));

                // Display players, excluding favorites
                foreach (var player in rankedPlayers)
                {
                    if (!favoritePlayerNames.Contains(player.Name))
                    {
                        var playerControl = new PlayerControl(player);
                        FlpPlayersDisplay.Controls.Add(playerControl);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading players: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void FlpFavoritePlayers_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("PlayerControls"))
            {
                e.Effect = DragDropEffects.Move;
            }
        }

        private async void FlpFavoritePlayers_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("PlayerControls"))
            {
                var playerControls = (List<PlayerControl>)e.Data.GetData("PlayerControls");
                if (playerControls != null)
                {
                    // Check if adding these players would exceed the 3-player limit
                    if (FlpFavoritePlayers.Controls.Count + playerControls.Count > 3)
                    {
                        MessageBox.Show("You can only have 3 favorite players!", "Maximum Favorites Reached", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    foreach (var playerControl in playerControls)
                    {
                        // Check for duplicates before adding
                        if (FlpFavoritePlayers.Controls.Cast<PlayerControl>().Any(pc =>
                            pc.PlayerData.FullName == playerControl.PlayerData.FullName &&
                            pc.PlayerData.ShirtNumber == playerControl.PlayerData.ShirtNumber))
                        {
                            MessageBox.Show("No duplicates allowed!", "Duplicate Player", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            continue; // Skip adding if player already exists
                        }

                        // Remove from original container
                        if (playerControl.Parent != null)
                        {
                            playerControl.Parent.Controls.Remove(playerControl);
                        }

                        // Set IsFavorite to true
                        playerControl.PlayerData.IsFavorite = true;
                        playerControl.SetPlayer(playerControl.PlayerData);

                        // Add to favorites
                        FlpFavoritePlayers.Controls.Add(playerControl);
                    }

                    // Automatically save the updated favorites
                    await SaveFavoritePlayersToFile();
                }
            }
        }

        private void FlpPlayersDisplay_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("PlayerControls"))
            {
                e.Effect = DragDropEffects.Move;
            }
        }

        private async void FlpPlayersDisplay_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("PlayerControls"))
            {
                var playerControls = (List<PlayerControl>)e.Data.GetData("PlayerControls");
                if (playerControls != null)
                {
                    foreach (var playerControl in playerControls)
                    {
                        // Remove from original container
                        if (playerControl.Parent != null)
                        {
                            playerControl.Parent.Controls.Remove(playerControl);
                        }

                        // Set IsFavorite to false
                        playerControl.PlayerData.IsFavorite = false;
                        playerControl.SetPlayer(playerControl.PlayerData);

                        // Add to main display
                        FlpPlayersDisplay.Controls.Add(playerControl);
                    }

                    // Automatically save the updated favorites
                    await SaveFavoritePlayersToFile();
                }
            }
        }

        private async Task SaveFavoritePlayersToFile()
        {
            try
            {
                List<Player> favoritePlayers = new List<Player>();
                foreach (Control control in FlpFavoritePlayers.Controls)
                {
                    if (control is PlayerControl playerControl)
                    {
                        favoritePlayers.Add(playerControl.PlayerData);
                    }
                }

                // Define both runtime and source file paths
                string genderFolder = currentGender == "Men" ? "Male" : "Female";
                string runtimeFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", genderFolder, $"{currentGender.ToLower()}_favorite_players.json");
                string sourceFilePath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\ClassLibrary\Data", genderFolder, $"{currentGender.ToLower()}_favorite_players.json"));

                // Ensure directories exist
                Directory.CreateDirectory(Path.GetDirectoryName(runtimeFilePath));
                Directory.CreateDirectory(Path.GetDirectoryName(sourceFilePath));

                // Serialize the favorite players
                string json = JsonSerializer.Serialize(favoritePlayers, new JsonSerializerOptions { WriteIndented = true });

                // Save to runtime file
                await File.WriteAllTextAsync(runtimeFilePath, json);

                // Save to source file
                await File.WriteAllTextAsync(sourceFilePath, json);

                // Also update the IsFavorite property in the main players file
                await UpdateFavoriteStatusInMainPlayersFile(favoritePlayers);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error auto-saving favorite players: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task LoadTeamsForComboBox()
        {
            try
            {
                var worldCupDataElement = currentGender == "Men"
                    ? await _worldCupService.LoadMenWorldCupDataJsonElement()
                    : await _worldCupService.LoadWomenWorldCupDataJsonElement();

                if (worldCupDataElement.TryGetProperty("Teams", out var teamsElement))
                {
                    _teams = JsonSerializer.Deserialize<List<dynamic>>(teamsElement.GetRawText());
                    _sortedTeams = _teams.OrderBy(t => t.GetProperty("country").GetString()).ToList();

                    // Map to a custom object for display
                    var displayTeams = _sortedTeams.Select(t => new
                    {
                        Name = $"{t.GetProperty("country").GetString()} ({t.GetProperty("fifa_code").GetString()})",
                        FifaCode = t.GetProperty("fifa_code").GetString(),
                        Country = t.GetProperty("country").GetString() // Add original country name
                    }).ToList();

                    CbTeams.DataSource = new BindingSource(displayTeams, null);
                    CbTeams.DisplayMember = "Name";
                    CbTeams.ValueMember = "FifaCode";

                    CbTeamforPlayers.DataSource = new BindingSource(displayTeams, null);
                    CbTeamforPlayers.DisplayMember = "Name";
                    CbTeamforPlayers.ValueMember = "FifaCode";

                    // Try to load and select the favorite team if it exists
                    string favoriteTeamPath = GetFavoriteTeamFilePath();
                    if (File.Exists(favoriteTeamPath))
                    {
                        string favoriteTeamContent = await File.ReadAllTextAsync(favoriteTeamPath);
                        var match = System.Text.RegularExpressions.Regex.Match(favoriteTeamContent, @"\((.+)\)");
                        if (match.Success)
                        {
                            string favTeamFifaCode = match.Groups[1].Value;
                            var favTeam = displayTeams.FirstOrDefault(t => t.FifaCode == favTeamFifaCode);
                            if (favTeam != null)
                            {
                                CbTeams.SelectedItem = favTeam;
                                CbTeamforPlayers.SelectedItem = favTeam;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading teams: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSetDetails_Click(object sender, EventArgs e)
        {
            var selectedPlayers = GetSelectedPlayers();
            if (selectedPlayers.Count == 1)
            {
                var detailsForm = new PlayerDetailsForm(selectedPlayers[0], currentGender);
                detailsForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select exactly one player to see details.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ConfirmBtn_Click(object sender, EventArgs e)
        {

        }

        private void BtnPlayerRankingsGoals_Click(object sender, EventArgs e)
        {
            ShowPlayerRankingsByGoals();
        }

        private void BtnShowRankingsYC_Click(object sender, EventArgs e)
        {
            ShowPlayerRankingsByYellowCards();
        }

        private async void ShowPlayerRankingsByGoals()
        {
            if (isLoading) return;

            try
            {
                SetLoadingState(true);

                // Load players from men_players.json instead of ranking files
                var teams = await _playerDataService.LoadTeamPlayers(currentGender);
                var allPlayers = new List<Player>();

                // Extract all players from all teams
                foreach (var team in teams)
                {
                    allPlayers.AddRange(team.Players);
                }

                // Filter players with goals and sort by goals scored (descending)
                var playersWithGoals = allPlayers
                    .Where(p => p.GoalsScored > 0)
                    .OrderByDescending(p => p.GoalsScored)
                    .ThenBy(p => p.FullName) // Secondary sort by name
                    .Take(10) // Top 10 goal scorers
                    .ToList();

                DisplayPlayerRankings(playersWithGoals, "Goals Scored");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading goal rankings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private async void ShowPlayerRankingsByYellowCards()
        {
            if (isLoading) return;

            try
            {
                SetLoadingState(true);

                // Load players from men_players.json instead of ranking files
                var teams = await _playerDataService.LoadTeamPlayers(currentGender);
                var allPlayers = new List<Player>();

                // Extract all players from all teams
                foreach (var team in teams)
                {
                    allPlayers.AddRange(team.Players);
                }

                // Filter players with yellow cards and sort by yellow cards (descending)
                var playersWithYellowCards = allPlayers
                    .Where(p => p.YellowCards > 0)
                    .OrderByDescending(p => p.YellowCards)
                    .ThenBy(p => p.FullName) // Secondary sort by name
                    .Take(10) // Top 10 players with yellow cards
                    .ToList();

                DisplayPlayerRankings(playersWithYellowCards, "Yellow Cards");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading yellow card rankings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void DisplayPlayerRankings(List<Player> players, string rankingType)
        {
            var rankingData = new List<PlayerRankingDisplay>();

            for (int i = 0; i < players.Count; i++)
            {
                var player = players[i];
                var rankingItem = new PlayerRankingDisplay
                {
                    Rank = i + 1,
                    FullName = player.FullName,
                    Appearances = player.Appearances,
                    GoalsScored = player.GoalsScored,
                    YellowCards = player.YellowCards,
                    PlayerImage = LoadPlayerImage(player.ImageFileName)
                };
                rankingData.Add(rankingItem);
            }

            DTGPlayerRankings.DataSource = rankingData;
        }

        private Image LoadPlayerImage(string imageFileName)
        {
            try
            {
                if (string.IsNullOrEmpty(imageFileName))
                {
                    // Load default image
                    string defaultImagePath = Path.Combine(Application.StartupPath, "Resources", "DefaultPlayerPic.jpeg");
                    if (File.Exists(defaultImagePath))
                    {
                        return Image.FromFile(defaultImagePath);
                    }
                    return null;
                }

                string imagePath = Path.Combine(Application.StartupPath, "Resources", "players", imageFileName);
                if (File.Exists(imagePath))
                {
                    return Image.FromFile(imagePath);
                }

                // Fallback to default image
                string fallbackImagePath = Path.Combine(Application.StartupPath, "Resources", "DefaultPlayerPic.jpeg");
                if (File.Exists(fallbackImagePath))
                {
                    return Image.FromFile(fallbackImagePath);
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        // Helper class for displaying player rankings in DataGridView
        public class PlayerRankingDisplay
        {
            public int Rank { get; set; }
            public string FullName { get; set; }
            public int Appearances { get; set; }
            public int GoalsScored { get; set; }
            public int YellowCards { get; set; }
            public Image PlayerImage { get; set; }
        }

        // Helper class for displaying match rankings in DataGridView
        public class MatchRankingDisplay
        {
            public int Rank { get; set; }
            public string Location { get; set; }
            public string Venue { get; set; }
            public string HomeTeam { get; set; }
            public string AwayTeam { get; set; }
            public int Visitors { get; set; }
        }

        private async Task LoadWorldCupDataOnStartup()
        {
            try
            {
                // Check if player data already exists
                string playersFilePath = currentGender == "Men"
                    ? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "Male", "men_players.json")
                    : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "Female", "women_players.json");

                if (!File.Exists(playersFilePath))
                {
                    // Load World Cup data and create player statistics
                    if (currentGender == "Men")
                    {
                        await _worldCupService.SaveMenWorldCupData();
                        var (success, logMessage) = await _playerDataService.SaveTeamPlayers("Men");
                        if (!success)
                        {
                            Console.WriteLine($"Warning: Failed to save team players: {logMessage}");
                        }
                        await _playerDataService.SavePlayerRankings("Men");
                    }
                    else
                    {
                        await _worldCupService.SaveWomenWorldCupData();
                        var (success, logMessage) = await _playerDataService.SaveTeamPlayers("Women");
                        if (!success)
                        {
                            Console.WriteLine($"Warning: Failed to save team players: {logMessage}");
                        }
                        await _playerDataService.SavePlayerRankings("Women");
                    }
                }

                await _playerDataService.SaveMatchVisitorRankings(currentGender);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Failed to load World Cup data on startup: {ex.Message}");
            }
        }

        private async Task SynchronizeFavoritesOnStartup()
        {
            try
            {
                // Load existing favorite players
                List<Player> favoritePlayers = new List<Player>();
                string favoritePlayersPath = GetFavoritePlayersFilePath();

                if (File.Exists(favoritePlayersPath))
                {
                    string json = await File.ReadAllTextAsync(favoritePlayersPath);
                    favoritePlayers = JsonSerializer.Deserialize<List<Player>>(json);

                    // Update the IsFavorite property in the main players file
                    await UpdateFavoriteStatusInMainPlayersFile(favoritePlayers);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Failed to synchronize favorites on startup: {ex.Message}");
            }
        }

        private async void BtnShowMatchRanking_Click(object sender, EventArgs e)
        {
            ShowMatchRankings();
        }

        private async void ShowMatchRankings()
        {
            if (isLoading) return;

            try
            {
                SetLoadingState(true);

                // Load match visitor rankings
                var matchRankings = await _playerDataService.LoadMatchVisitorRankings(currentGender);

                // Create display data with ranking numbers
                var rankingData = new List<MatchRankingDisplay>();

                for (int i = 0; i < matchRankings.Count; i++)
                {
                    var match = matchRankings[i];
                    var rankingItem = new MatchRankingDisplay
                    {
                        Rank = i + 1,
                        Location = match.Location,
                        Venue = match.Venue,
                        HomeTeam = match.HomeTeam,
                        AwayTeam = match.AwayTeam,
                        Visitors = match.Visitors
                    };
                    rankingData.Add(rankingItem);
                }

                DTGMatchRankings.DataSource = rankingData;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading match rankings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            dgvToPrintList.Clear();

            if (DTGPlayerRankings.DataSource != null && DTGPlayerRankings.Rows.Count > 0)
            {
                dgvToPrintList.Add(DTGPlayerRankings);
            }
            if (DTGMatchRankings.DataSource != null && DTGMatchRankings.Rows.Count > 0)
            {
                dgvToPrintList.Add(DTGMatchRankings);
            }

            if (dgvToPrintList.Count == 0)
            {
                MessageBox.Show("There is no data to print.", "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            printRowIndex = 0;
            currentDgvIndex = 0;

            PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();
            printPreviewDialog.Document = printDocument;
            printPreviewDialog.Width = 800;
            printPreviewDialog.Height = 600;
            printPreviewDialog.ShowDialog();
        }

        private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            if (dgvToPrintList.Count == 0 || currentDgvIndex >= dgvToPrintList.Count || e.Graphics == null)
            {
                e.HasMorePages = false;
                return;
            }

            Graphics g = e.Graphics;
            float yPos = e.MarginBounds.Top;
            var currentDgv = dgvToPrintList[currentDgvIndex];

            if (printRowIndex == 0)
            {
                string title = currentDgv == DTGPlayerRankings ? "Player Rankings" : "Match Attendance Rankings";
                g.DrawString(title, new Font("Segoe UI", 16, FontStyle.Bold), Brushes.Black, e.MarginBounds.Left, yPos);
                yPos += 40;
            }

            var headerFont = new Font("Segoe UI", 12, FontStyle.Bold);
            var rowFont = new Font("Segoe UI", 10);
            var columnWidths = new List<float>();
            float totalWidth = currentDgv.Columns.GetColumnsWidth(DataGridViewElementStates.Visible);
            if (totalWidth <= 0) return;

            foreach (DataGridViewColumn col in currentDgv.Columns)
            {
                if (col.Visible)
                {
                    columnWidths.Add((col.Width / totalWidth) * e.MarginBounds.Width);
                }
            }

            if (printRowIndex == 0)
            {
                float xPos = e.MarginBounds.Left;
                int colIndex = 0;
                float headerHeight = 0;
                foreach (DataGridViewColumn col in currentDgv.Columns)
                {
                    if (!col.Visible) continue;
                    headerHeight = g.MeasureString(col.HeaderText, headerFont).Height + 10;
                    g.FillRectangle(Brushes.LightGray, xPos, yPos, columnWidths[colIndex], headerHeight);
                    g.DrawRectangle(Pens.Black, xPos, yPos, columnWidths[colIndex], headerHeight);
                    g.DrawString(col.HeaderText, headerFont, Brushes.Black, xPos + 5, yPos + 4);
                    xPos += columnWidths[colIndex];
                    colIndex++;
                }
                yPos += headerHeight;
            }

            while (printRowIndex < currentDgv.Rows.Count)
            {
                DataGridViewRow row = currentDgv.Rows[printRowIndex];
                float rowHeight = row.Height > 0 ? row.Height : rowFont.GetHeight(g) + 10;

                if (yPos + rowHeight > e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }

                float xPos = e.MarginBounds.Left;
                int colIndex = 0;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (!currentDgv.Columns[cell.ColumnIndex].Visible) continue;

                    if (cell.Value is Image img)
                    {
                        var imgRect = new Rectangle((int)xPos + 5, (int)yPos + 5, (int)columnWidths[colIndex] - 10, (int)rowHeight - 10);
                        g.DrawImage(img, imgRect);
                    }
                    else
                    {
                        g.DrawString(cell.FormattedValue?.ToString() ?? "", rowFont, Brushes.Black, xPos + 5, yPos + 4);
                    }
                    g.DrawRectangle(Pens.Black, xPos, yPos, columnWidths[colIndex], rowHeight);
                    xPos += columnWidths[colIndex];
                    colIndex++;
                }
                yPos += rowHeight;
                printRowIndex++;
            }

            currentDgvIndex++;
            printRowIndex = 0;

            if (currentDgvIndex < dgvToPrintList.Count)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                currentDgvIndex = 0;
            }
        }

        private void ApplyLanguage()
        {
            if (currentLanguage == "Croatian")
            {
                // Tab names
                Favorites.Text = "Vaši favoriti";
                Rankings.Text = "Poredak";
                Settings.Text = "Postavke";
                // Labels
                LbFavoritePlayers.Text = "Omiljeni igrači";
                LbLoading.Text = "Učitavanje...";
                LbPlayers.Text = "Igrači";
                LbFavTeam.Text = "Omiljeni tim";
                LanguageLb.Text = "Odaberite jezik";
                GenderLb.Text = "Odaberite spol";
                // Buttons
                BtnSaveFavTeam.Text = "Spremi omiljeni tim";
                BtnSetDetails.Text = "Postavi detalje";
                SaveFavAndImg.Text = "Spremi i sliku";
                BtnSaveTeamPlayers.Text = "Prikaži igrače tima";
                BtnShowMatchRanking.Text = "Prikaži poredak utakmica";
                BtnPrint.Text = "Ispis";
                BtnPlayerRankingsGoals.Text = "Golovi igrača";
                BtnShowRankingsYC.Text = "Žuti kartoni";
                ConfirmBtn.Text = "Potvrdi";
                CancelBtn.Text = "Odustani";
            }
            else // English or default
            {
                Favorites.Text = "Your Favorites";
                Rankings.Text = "Rankings";
                Settings.Text = "Settings";
                LbFavoritePlayers.Text = "Favorite Players";
                LbLoading.Text = "Loading...";
                LbPlayers.Text = "Players";
                LbFavTeam.Text = "Favorite Team";
                LanguageLb.Text = "Select Language";
                GenderLb.Text = "Select Gender";
                BtnSaveFavTeam.Text = "Save Favorite Team";
                BtnSetDetails.Text = "Set Details";
                SaveFavAndImg.Text = "Save Changes";
                BtnSaveTeamPlayers.Text = "Show Team Players";
                BtnShowMatchRanking.Text = "Show Match Rankings";
                BtnPrint.Text = "Print";
                BtnPlayerRankingsGoals.Text = "Player Goals";
                BtnShowRankingsYC.Text = "Yellow Cards";
                ConfirmBtn.Text = "Confirm";
                CancelBtn.Text = "Cancel";
            }
        }

        private void LbFavoritePlayers_Click(object sender, EventArgs e)
        {

        }

        private void CbTeams_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
