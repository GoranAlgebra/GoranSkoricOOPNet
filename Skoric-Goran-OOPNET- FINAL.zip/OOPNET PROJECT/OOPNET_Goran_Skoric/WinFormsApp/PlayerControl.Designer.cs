namespace WinFormsApp
{
    partial class PlayerControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// PLAYER CARDS
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbPlayerName = new System.Windows.Forms.Label();
            this.LbPlayerNumber = new System.Windows.Forms.Label();
            this.LbPlayerPosition = new System.Windows.Forms.Label();
            this.LbIsCaptain = new System.Windows.Forms.Label();
            this.LbIsFavorite = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LbPlayerName
            // 
            this.LbPlayerName.AutoSize = true;
            this.LbPlayerName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.LbPlayerName.Location = new System.Drawing.Point(3, 0);
            this.LbPlayerName.Name = "LbPlayerName";
            this.LbPlayerName.Size = new System.Drawing.Size(89, 20);
            this.LbPlayerName.TabIndex = 0;
            this.LbPlayerName.Text = "Player Name";
            // 
            // LbPlayerNumber
            // 
            this.LbPlayerNumber.AutoSize = true;
            this.LbPlayerNumber.Location = new System.Drawing.Point(3, 20);
            this.LbPlayerNumber.Name = "LbPlayerNumber";
            this.LbPlayerNumber.Size = new System.Drawing.Size(61, 20);
            this.LbPlayerNumber.TabIndex = 1;
            this.LbPlayerNumber.Text = "Number:";
            // 
            // LbPlayerPosition
            // 
            this.LbPlayerPosition.AutoSize = true;
            this.LbPlayerPosition.Location = new System.Drawing.Point(3, 40);
            this.LbPlayerPosition.Name = "LbPlayerPosition";
            this.LbPlayerPosition.Size = new System.Drawing.Size(64, 20);
            this.LbPlayerPosition.TabIndex = 2;
            this.LbPlayerPosition.Text = "Position:";
            // 
            // LbIsCaptain
            // 
            this.LbIsCaptain.AutoSize = true;
            this.LbIsCaptain.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.LbIsCaptain.Location = new System.Drawing.Point(3, 60);
            this.LbIsCaptain.Name = "LbIsCaptain";
            this.LbIsCaptain.Size = new System.Drawing.Size(60, 20);
            this.LbIsCaptain.TabIndex = 3;
            this.LbIsCaptain.Text = "(C)";
            this.LbIsCaptain.Visible = false;
            // 
            // LbIsFavorite
            // 
            this.LbIsFavorite.AutoSize = true;
            this.LbIsFavorite.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.LbIsFavorite.ForeColor = System.Drawing.Color.Gold;
            this.LbIsFavorite.Location = new System.Drawing.Point(70, 60);
            this.LbIsFavorite.Name = "LbIsFavorite";
            this.LbIsFavorite.Size = new System.Drawing.Size(23, 20);
            this.LbIsFavorite.TabIndex = 4;
            this.LbIsFavorite.Text = "★";
            this.LbIsFavorite.Visible = false;
            // 
            // PlayerControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.LbIsFavorite);
            this.Controls.Add(this.LbIsCaptain);
            this.Controls.Add(this.LbPlayerPosition);
            this.Controls.Add(this.LbPlayerNumber);
            this.Controls.Add(this.LbPlayerName);
            this.Name = "PlayerControl";
            this.Size = new System.Drawing.Size(150, 80);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LbPlayerName;
        private System.Windows.Forms.Label LbPlayerNumber;
        private System.Windows.Forms.Label LbPlayerPosition;
        private System.Windows.Forms.Label LbIsCaptain;
        private System.Windows.Forms.Label LbIsFavorite;
    }
} 