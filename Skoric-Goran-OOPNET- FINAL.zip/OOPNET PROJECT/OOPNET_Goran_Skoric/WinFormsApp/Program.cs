using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp
{
    internal static class Program
    {
        public static string SettingsFilePath = "user_settings.txt";

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            
            try
            {
                // Check if settings file exists
                if (!File.Exists(SettingsFilePath))
                {
                    // Show initial settings form if settings don't exist
                    using (var settingsForm = new InitialSettingsForm())
                    {
                        if (settingsForm.ShowDialog() != DialogResult.OK)
                        {
                            return; // Exit if user cancels
                        }
                    }
                }

                // Create and show main form
                Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static async Task SaveSettingsAsync(string language, string gender)
        {
            try
            {
                string[] settings = new string[] { language, gender };
                await File.WriteAllLinesAsync(SettingsFilePath, settings);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static async Task<(string language, string gender)> LoadSettingsAsync()
        {
            try
            {
                if (File.Exists(SettingsFilePath))
                {
                    string[] settings = await File.ReadAllLinesAsync(SettingsFilePath);
                    if (settings.Length >= 2)
                    {
                        return (settings[0], settings[1]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return ("English", "Men"); // Default values
        }
    }
}