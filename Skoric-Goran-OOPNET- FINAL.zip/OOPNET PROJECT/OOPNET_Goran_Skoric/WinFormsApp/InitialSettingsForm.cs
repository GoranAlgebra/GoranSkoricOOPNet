﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp
{
    public partial class InitialSettingsForm : Form
    {
        private bool isLoading = false;

        public InitialSettingsForm()
        {
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            // Set default selections
            LanguageCb.SelectedIndex = 0;
            GenderCb.SelectedIndex = 0;

            // Wire up button events
            ConfirmBtn.Click += ConfirmBtn_Click;
            CancelBtn.Click += CancelBtn_Click;
        }

        private async void ConfirmBtn_Click(object sender, EventArgs e)
        {
            if (isLoading) return;

            if (LanguageCb.SelectedItem == null || GenderCb.SelectedItem == null)
            {
                MessageBox.Show("Please select all options before proceeding.", "Incomplete Settings", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                SetLoadingState(true);

                // Save settings asynchronously
                await Program.SaveSettingsAsync(
                    LanguageCb.SelectedItem.ToString(),
                    GenderCb.SelectedItem.ToString()
                );

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            if (isLoading) return;
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void SetLoadingState(bool loading)
        {
            isLoading = loading;
            ConfirmBtn.Enabled = !loading;
            CancelBtn.Enabled = !loading;
            LanguageCb.Enabled = !loading;
            GenderCb.Enabled = !loading;

            if (loading)
            {
                ConfirmBtn.Text = "Saving...";
                // You could add a loading spinner here
            }
            else
            {
                ConfirmBtn.Text = "Confirm";
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (DialogResult != DialogResult.OK && DialogResult != DialogResult.Cancel)
            {
                DialogResult = DialogResult.Cancel;
            }
        }
    }
}
