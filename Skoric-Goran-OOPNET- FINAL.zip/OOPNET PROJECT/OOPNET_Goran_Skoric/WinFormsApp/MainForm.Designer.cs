﻿namespace WinFormsApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MainFormTab = new TabControl();
            Favorites = new TabPage();
            LbFavoritePlayers = new Label();
            LbLoading = new Label();
            BtnSaveTeamPlayers = new Button();
            CbTeamforPlayers = new ComboBox();
            BtnSetDetails = new Button();
            SaveFavAndImg = new Button();
            LbPlayers = new Label();
            FlpPlayersDisplay = new FlowLayoutPanel();
            FlpFavoritePlayers = new FlowLayoutPanel();
            BtnSaveFavTeam = new Button();
            CbTeams = new ComboBox();
            LbFavTeam = new Label();
            Rankings = new TabPage();
            BtnShowRankingsYC = new Button();
            DTGPlayerRankings = new DataGridView();
            DTGMatchRankings = new DataGridView();
            BtnPrint = new Button();
            BtnPlayerRankingsGoals = new Button();
            BtnShowMatchRanking = new Button();
            Settings = new TabPage();
            CancelBtn = new Button();
            ConfirmBtn = new Button();
            LanguageLb = new Label();
            GenderLb = new Label();
            LanguageCb = new ComboBox();
            GenderCb = new ComboBox();
            MainFormTab.SuspendLayout();
            Favorites.SuspendLayout();
            Rankings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DTGPlayerRankings).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DTGMatchRankings).BeginInit();
            Settings.SuspendLayout();
            SuspendLayout();
            // 
            // MainFormTab
            // 
            MainFormTab.Controls.Add(Favorites);
            MainFormTab.Controls.Add(Rankings);
            MainFormTab.Controls.Add(Settings);
            MainFormTab.Dock = DockStyle.Fill;
            MainFormTab.Location = new Point(0, 0);
            MainFormTab.Name = "MainFormTab";
            MainFormTab.SelectedIndex = 0;
            MainFormTab.Size = new Size(748, 639);
            MainFormTab.TabIndex = 0;
            // 
            // Favorites
            // 
            Favorites.Controls.Add(LbFavoritePlayers);
            Favorites.Controls.Add(LbLoading);
            Favorites.Controls.Add(BtnSaveTeamPlayers);
            Favorites.Controls.Add(CbTeamforPlayers);
            Favorites.Controls.Add(BtnSetDetails);
            Favorites.Controls.Add(SaveFavAndImg);
            Favorites.Controls.Add(LbPlayers);
            Favorites.Controls.Add(FlpPlayersDisplay);
            Favorites.Controls.Add(FlpFavoritePlayers);
            Favorites.Controls.Add(BtnSaveFavTeam);
            Favorites.Controls.Add(CbTeams);
            Favorites.Controls.Add(LbFavTeam);
            Favorites.Location = new Point(4, 29);
            Favorites.Name = "Favorites";
            Favorites.Padding = new Padding(3);
            Favorites.Size = new Size(740, 606);
            Favorites.TabIndex = 0;
            Favorites.Text = "Your Favorites";
            Favorites.UseVisualStyleBackColor = true;
            // 
            // LbFavoritePlayers
            // 
            LbFavoritePlayers.AutoSize = true;
            LbFavoritePlayers.Location = new Point(329, 163);
            LbFavoritePlayers.Name = "LbFavoritePlayers";
            LbFavoritePlayers.Size = new Size(111, 20);
            LbFavoritePlayers.TabIndex = 19;
            LbFavoritePlayers.Text = "Favorite Players";
            LbFavoritePlayers.Click += LbFavoritePlayers_Click;
            // 
            // LbLoading
            // 
            LbLoading.AutoSize = true;
            LbLoading.Location = new Point(24, 569);
            LbLoading.Name = "LbLoading";
            LbLoading.Size = new Size(72, 20);
            LbLoading.TabIndex = 18;
            LbLoading.Text = "Loading...";
            // 
            // BtnSaveTeamPlayers
            // 
            BtnSaveTeamPlayers.Location = new Point(186, 95);
            BtnSaveTeamPlayers.Name = "BtnSaveTeamPlayers";
            BtnSaveTeamPlayers.Size = new Size(151, 29);
            BtnSaveTeamPlayers.TabIndex = 15;
            BtnSaveTeamPlayers.Text = "Show Team Players";
            BtnSaveTeamPlayers.UseVisualStyleBackColor = true;
            // 
            // CbTeamforPlayers
            // 
            CbTeamforPlayers.FormattingEnabled = true;
            CbTeamforPlayers.Location = new Point(32, 95);
            CbTeamforPlayers.Name = "CbTeamforPlayers";
            CbTeamforPlayers.Size = new Size(151, 28);
            CbTeamforPlayers.TabIndex = 14;
            // 
            // BtnSetDetails
            // 
            BtnSetDetails.Location = new Point(529, 326);
            BtnSetDetails.Name = "BtnSetDetails";
            BtnSetDetails.Size = new Size(119, 57);
            BtnSetDetails.TabIndex = 11;
            BtnSetDetails.Text = "See Player Details";
            BtnSetDetails.UseVisualStyleBackColor = true;
            BtnSetDetails.Click += BtnSetDetails_Click;
            // 
            // SaveFavAndImg
            // 
            SaveFavAndImg.Location = new Point(201, 428);
            SaveFavAndImg.Name = "SaveFavAndImg";
            SaveFavAndImg.Size = new Size(122, 49);
            SaveFavAndImg.TabIndex = 9;
            SaveFavAndImg.Text = "Save Changes";
            SaveFavAndImg.UseVisualStyleBackColor = true;
            // 
            // LbPlayers
            // 
            LbPlayers.AutoSize = true;
            LbPlayers.Location = new Point(90, 163);
            LbPlayers.Name = "LbPlayers";
            LbPlayers.Size = new Size(55, 20);
            LbPlayers.TabIndex = 7;
            LbPlayers.Text = "Players";
            // 
            // FlpPlayersDisplay
            // 
            FlpPlayersDisplay.AllowDrop = true;
            FlpPlayersDisplay.AutoScroll = true;
            FlpPlayersDisplay.BorderStyle = BorderStyle.FixedSingle;
            FlpPlayersDisplay.Location = new Point(24, 187);
            FlpPlayersDisplay.Name = "FlpPlayersDisplay";
            FlpPlayersDisplay.Size = new Size(220, 196);
            FlpPlayersDisplay.TabIndex = 16;
            // 
            // FlpFavoritePlayers
            // 
            FlpFavoritePlayers.AllowDrop = true;
            FlpFavoritePlayers.AutoScroll = true;
            FlpFavoritePlayers.BorderStyle = BorderStyle.FixedSingle;
            FlpFavoritePlayers.Location = new Point(272, 187);
            FlpFavoritePlayers.Name = "FlpFavoritePlayers";
            FlpFavoritePlayers.Size = new Size(220, 194);
            FlpFavoritePlayers.TabIndex = 17;
            // 
            // BtnSaveFavTeam
            // 
            BtnSaveFavTeam.Location = new Point(186, 57);
            BtnSaveFavTeam.Name = "BtnSaveFavTeam";
            BtnSaveFavTeam.Size = new Size(151, 29);
            BtnSaveFavTeam.TabIndex = 2;
            BtnSaveFavTeam.Text = "Save Favorite Team\r\n";
            BtnSaveFavTeam.UseVisualStyleBackColor = true;
            // 
            // CbTeams
            // 
            CbTeams.FormattingEnabled = true;
            CbTeams.Location = new Point(32, 57);
            CbTeams.Name = "CbTeams";
            CbTeams.Size = new Size(151, 28);
            CbTeams.TabIndex = 1;
            CbTeams.SelectedIndexChanged += CbTeams_SelectedIndexChanged;
            // 
            // LbFavTeam
            // 
            LbFavTeam.AutoSize = true;
            LbFavTeam.Location = new Point(32, 34);
            LbFavTeam.Name = "LbFavTeam";
            LbFavTeam.Size = new Size(145, 20);
            LbFavTeam.TabIndex = 0;
            LbFavTeam.Text = "Select Favorite Team";
            // 
            // Rankings
            // 
            Rankings.Controls.Add(BtnShowRankingsYC);
            Rankings.Controls.Add(DTGPlayerRankings);
            Rankings.Controls.Add(DTGMatchRankings);
            Rankings.Controls.Add(BtnPrint);
            Rankings.Controls.Add(BtnPlayerRankingsGoals);
            Rankings.Controls.Add(BtnShowMatchRanking);
            Rankings.Location = new Point(4, 29);
            Rankings.Name = "Rankings";
            Rankings.Padding = new Padding(3);
            Rankings.Size = new Size(740, 606);
            Rankings.TabIndex = 1;
            Rankings.Text = "Rankings";
            Rankings.UseVisualStyleBackColor = true;
            // 
            // BtnShowRankingsYC
            // 
            BtnShowRankingsYC.Location = new Point(611, 249);
            BtnShowRankingsYC.Name = "BtnShowRankingsYC";
            BtnShowRankingsYC.Size = new Size(112, 97);
            BtnShowRankingsYC.TabIndex = 20;
            BtnShowRankingsYC.Text = "Show Player Rankings By Yellow Cards";
            BtnShowRankingsYC.UseVisualStyleBackColor = true;
            // 
            // DTGPlayerRankings
            // 
            DTGPlayerRankings.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DTGPlayerRankings.Location = new Point(40, 249);
            DTGPlayerRankings.Name = "DTGPlayerRankings";
            DTGPlayerRankings.RowHeadersWidth = 51;
            DTGPlayerRankings.Size = new Size(565, 208);
            DTGPlayerRankings.TabIndex = 19;
            // 
            // DTGMatchRankings
            // 
            DTGMatchRankings.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DTGMatchRankings.Location = new Point(40, 41);
            DTGMatchRankings.Name = "DTGMatchRankings";
            DTGMatchRankings.RowHeadersWidth = 51;
            DTGMatchRankings.Size = new Size(565, 202);
            DTGMatchRankings.TabIndex = 18;
            DTGMatchRankings.CellContentClick += dataGridView1_CellContentClick;
            // 
            // BtnPrint
            // 
            BtnPrint.Location = new Point(144, 479);
            BtnPrint.Name = "BtnPrint";
            BtnPrint.Size = new Size(374, 69);
            BtnPrint.TabIndex = 6;
            BtnPrint.Text = "Print Rankings (PDF)";
            BtnPrint.UseVisualStyleBackColor = true;
            // 
            // BtnPlayerRankingsGoals
            // 
            BtnPlayerRankingsGoals.Location = new Point(611, 360);
            BtnPlayerRankingsGoals.Name = "BtnPlayerRankingsGoals";
            BtnPlayerRankingsGoals.Size = new Size(112, 97);
            BtnPlayerRankingsGoals.TabIndex = 5;
            BtnPlayerRankingsGoals.Text = "Show Player Rankings By Goals";
            BtnPlayerRankingsGoals.UseVisualStyleBackColor = true;
            // 
            // BtnShowMatchRanking
            // 
            BtnShowMatchRanking.Location = new Point(611, 41);
            BtnShowMatchRanking.Name = "BtnShowMatchRanking";
            BtnShowMatchRanking.Size = new Size(112, 97);
            BtnShowMatchRanking.TabIndex = 2;
            BtnShowMatchRanking.Text = "Show Match Rankings";
            BtnShowMatchRanking.UseVisualStyleBackColor = true;
            // 
            // Settings
            // 
            Settings.Controls.Add(CancelBtn);
            Settings.Controls.Add(ConfirmBtn);
            Settings.Controls.Add(LanguageLb);
            Settings.Controls.Add(GenderLb);
            Settings.Controls.Add(LanguageCb);
            Settings.Controls.Add(GenderCb);
            Settings.Location = new Point(4, 29);
            Settings.Name = "Settings";
            Settings.Padding = new Padding(3);
            Settings.Size = new Size(740, 606);
            Settings.TabIndex = 2;
            Settings.Text = "Settings";
            Settings.UseVisualStyleBackColor = true;
            // 
            // CancelBtn
            // 
            CancelBtn.Location = new Point(400, 285);
            CancelBtn.Name = "CancelBtn";
            CancelBtn.Size = new Size(94, 29);
            CancelBtn.TabIndex = 11;
            CancelBtn.Text = "Cancel";
            CancelBtn.UseVisualStyleBackColor = true;
            // 
            // ConfirmBtn
            // 
            ConfirmBtn.Location = new Point(238, 285);
            ConfirmBtn.Name = "ConfirmBtn";
            ConfirmBtn.Size = new Size(94, 29);
            ConfirmBtn.TabIndex = 10;
            ConfirmBtn.Text = "Confirm";
            ConfirmBtn.UseVisualStyleBackColor = true;
            ConfirmBtn.Click += ConfirmBtn_Click;
            // 
            // LanguageLb
            // 
            LanguageLb.AutoSize = true;
            LanguageLb.Font = new Font("Segoe UI", 12F);
            LanguageLb.Location = new Point(400, 215);
            LanguageLb.Name = "LanguageLb";
            LanguageLb.Size = new Size(154, 28);
            LanguageLb.TabIndex = 9;
            LanguageLb.Text = "Select Language";
            LanguageLb.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // GenderLb
            // 
            GenderLb.AutoSize = true;
            GenderLb.Font = new Font("Segoe UI", 12F);
            GenderLb.Location = new Point(400, 152);
            GenderLb.Name = "GenderLb";
            GenderLb.Size = new Size(133, 28);
            GenderLb.TabIndex = 8;
            GenderLb.Text = "Select Gender";
            GenderLb.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LanguageCb
            // 
            LanguageCb.DropDownStyle = ComboBoxStyle.DropDownList;
            LanguageCb.FormattingEnabled = true;
            LanguageCb.Location = new Point(214, 215);
            LanguageCb.Name = "LanguageCb";
            LanguageCb.Size = new Size(151, 28);
            LanguageCb.TabIndex = 7;
            // 
            // GenderCb
            // 
            GenderCb.DropDownStyle = ComboBoxStyle.DropDownList;
            GenderCb.FormattingEnabled = true;
            GenderCb.Location = new Point(214, 156);
            GenderCb.Name = "GenderCb";
            GenderCb.Size = new Size(151, 28);
            GenderCb.TabIndex = 6;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(748, 639);
            Controls.Add(MainFormTab);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "WorldCupStats";
            MainFormTab.ResumeLayout(false);
            Favorites.ResumeLayout(false);
            Favorites.PerformLayout();
            Rankings.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DTGPlayerRankings).EndInit();
            ((System.ComponentModel.ISupportInitialize)DTGMatchRankings).EndInit();
            Settings.ResumeLayout(false);
            Settings.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl MainFormTab;
        private TabPage Favorites;
        private TabPage Rankings;
        private TabPage Settings;
        private Button SaveFavAndImg;
        private Label LbPlayers;
        private FlowLayoutPanel FlpPlayersDisplay;
        private FlowLayoutPanel FlpFavoritePlayers;
        private Button BtnSaveFavTeam;
        private ComboBox CbTeams;
        private Label LbFavTeam;
        private Button BtnSetDetails;
        private Button BtnShowMatchRanking;
        private Button BtnPrint;
        private Button BtnPlayerRankingsGoals;
        private DataGridView DTGMatchRankings;
        private DataGridView DTGPlayerRankings;
        private Button CancelBtn;
        private Button ConfirmBtn;
        private Label LanguageLb;
        private Label GenderLb;
        private ComboBox LanguageCb;
        private ComboBox GenderCb;
        private Button BtnSaveTeamPlayers;
        private ComboBox CbTeamforPlayers;
        private Label LbLoading;
        private Button BtnShowRankingsYC;
        private Label LbFavoritePlayers;
    }
}