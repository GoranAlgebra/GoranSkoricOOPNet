using System.Drawing;
using System.Windows.Forms;
using ClassLibrary.Models;
using System.Collections.Generic;

namespace WinFormsApp
{
    public partial class PlayerControl : UserControl
    {
        public Player PlayerData { get; private set; }
        public bool IsSelected { get; private set; }

        public event EventHandler<PlayerControl> PlayerSelected;

        public PlayerControl()
        {
            InitializeComponent();
        }

        public PlayerControl(Player player) : this()
        {
            SetPlayer(player);
            PlayerData = player; // Store the player data
            
            // Enable drag functionality for the control itself
            this.MouseDown += PlayerControl_MouseDown;
            
            // Add right-click handlers for selection
            this.MouseClick += PlayerControl_MouseClick;
            LbPlayerName.MouseClick += PlayerControl_MouseClick;
            LbPlayerNumber.MouseClick += PlayerControl_MouseClick;
            LbPlayerPosition.MouseClick += PlayerControl_MouseClick;
            LbIsCaptain.MouseClick += PlayerControl_MouseClick;
            LbIsFavorite.MouseClick += PlayerControl_MouseClick;

            this.GiveFeedback += PlayerControl_GiveFeedback;
            this.QueryContinueDrag += PlayerControl_QueryContinueDrag;

            // Set cursor to hand to indicate clickable
            this.Cursor = Cursors.Hand;
        }

        public void SetPlayer(Player player)
        {
            LbPlayerName.Text = player.FullName;
            if (player.IsCaptain)
            {
                LbPlayerName.Text += " (C)";
            }
            LbPlayerNumber.Text = player.ShirtNumber.ToString();
            LbPlayerPosition.Text = player.Position;
            LbIsFavorite.Visible = player.IsFavorite; // Show star if favorite
            // You'll need to set the player image if you have it
            // PbPlayerImage.Image = ImageHelper.GetPlayerImage(player.ImageFileName);
        }

        private void PlayerControl_MouseClick(object sender, MouseEventArgs e)
        {
            // Handle left-clicks for primary selection, and right-clicks if needed for context menus etc.
            if (e.Button == MouseButtons.Left || e.Button == MouseButtons.Right)
            {
                // If Ctrl is not pressed, deselect all other cards first
                if (!Control.ModifierKeys.HasFlag(Keys.Control))
                {
                    // Raise event to deselect others. The MainForm will handle deselecting all other PlayerControls.
                    PlayerSelected?.Invoke(this, this); 
                }

                // Toggle selection state
                IsSelected = !IsSelected;
                
                // Update visual appearance
                this.BackColor = IsSelected ? Color.LightBlue : SystemColors.Control;
            }
        }

        public void Deselect()
        {
            if (IsSelected)
            {
                IsSelected = false;
                this.BackColor = SystemColors.Control;
            }
        }

        private void PlayerControl_MouseDown(object sender, MouseEventArgs e)
        {
            // Only start drag if it's a left-click
            if (e.Button == MouseButtons.Left)
            {
                // Create a list of selected controls to drag
                var selectedControls = new List<PlayerControl>();
                
                // If this control is selected, drag all selected controls
                if (IsSelected)
                {
                    // Get the parent FlowLayoutPanel
                    if (Parent is FlowLayoutPanel parentPanel)
                    {
                        // Add all selected controls from the same panel
                        foreach (Control control in parentPanel.Controls)
                        {
                            if (control is PlayerControl playerControl && playerControl.IsSelected)
                            {
                                selectedControls.Add(playerControl);
                            }
                        }
                    }
                }
                else
                {
                    // If this control is not selected, just drag this one
                    selectedControls.Add(this);
                }

                // Create a data object that can be used in drag and drop
                var data = new DataObject();
                data.SetData("PlayerControls", selectedControls);

                // Start the drag operation with the data object
                DoDragDrop(data, DragDropEffects.Move);
            }
        }

        private void PlayerControl_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {
            // MessageBox.Show("PlayerControl GiveFeedback event fired!"); // Removed: No longer needed after debugging
            // This event allows you to customize the cursor during drag-and-drop
            e.UseDefaultCursors = true; // Use default cursors based on e.Effect
        }

        private void PlayerControl_QueryContinueDrag(object sender, QueryContinueDragEventArgs e)
        {
            // This event allows you to cancel the drag-and-drop operation
            if (e.Action == DragAction.Cancel || e.Action == DragAction.Drop)
            {
                // If the user canceled the drag or the item has been dropped, stop dragging.
                // No action needed here, as setting e.Action handles continuation implicitly.
            }
            else
            {
                // Otherwise, the drag should continue. No explicit action needed.
            }
        }
    }
} 