﻿namespace WinFormsApp
{
    partial class PlayerDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PbPlayerDetails = new PictureBox();
            FlpPlayerDetails = new FlowLayoutPanel();
            playerCardExtended1 = new PlayerCardExtended();
            BtnChangePicture = new Button();
            ((System.ComponentModel.ISupportInitialize)PbPlayerDetails).BeginInit();
            FlpPlayerDetails.SuspendLayout();
            SuspendLayout();
            // 
            // PbPlayerDetails
            // 
            PbPlayerDetails.Location = new Point(12, 12);
            PbPlayerDetails.Name = "PbPlayerDetails";
            PbPlayerDetails.Size = new Size(200, 200);
            PbPlayerDetails.SizeMode = PictureBoxSizeMode.Zoom;
            PbPlayerDetails.TabIndex = 0;
            PbPlayerDetails.TabStop = false;
            // 
            // FlpPlayerDetails
            // 
            FlpPlayerDetails.AutoScroll = true;
            FlpPlayerDetails.Controls.Add(playerCardExtended1);
            FlpPlayerDetails.Location = new Point(218, 12);
            FlpPlayerDetails.Name = "FlpPlayerDetails";
            FlpPlayerDetails.Size = new Size(351, 257);
            FlpPlayerDetails.TabIndex = 1;
            FlpPlayerDetails.Paint += FlpPlayerDetails_Paint;
            // 
            // playerCardExtended1
            // 
            playerCardExtended1.Location = new Point(3, 3);
            playerCardExtended1.Name = "playerCardExtended1";
            playerCardExtended1.Size = new Size(280, 250);
            playerCardExtended1.TabIndex = 0;
            // 
            // BtnChangePicture
            // 
            BtnChangePicture.Location = new Point(11, 218);
            BtnChangePicture.Name = "BtnChangePicture";
            BtnChangePicture.Size = new Size(201, 47);
            BtnChangePicture.TabIndex = 2;
            BtnChangePicture.Text = "Change Picture";
            BtnChangePicture.UseVisualStyleBackColor = true;
            // 
            // PlayerDetailsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(661, 281);
            Controls.Add(BtnChangePicture);
            Controls.Add(FlpPlayerDetails);
            Controls.Add(PbPlayerDetails);
            Name = "PlayerDetailsForm";
            Text = "Player Details";
            ((System.ComponentModel.ISupportInitialize)PbPlayerDetails).EndInit();
            FlpPlayerDetails.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PbPlayerDetails;
        private System.Windows.Forms.FlowLayoutPanel FlpPlayerDetails;
        private PlayerCardExtended playerCardExtended1;
        private Button BtnChangePicture;
    }
}