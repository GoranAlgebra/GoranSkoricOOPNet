using System.Windows.Forms;

namespace WinFormsApp
{
    public partial class PlayerCardExtended : UserControl
    {
        public PlayerCardExtended()
        {
            InitializeComponent();
        }

        public void SetPlayerDetails(ClassLibrary.Models.Player player)
        {
            // Populate UI elements with player data
            // These labels will be created in the Designer.cs file
            lblName.Text = "Name: " + player.FullName;
            lblShirtNumber.Text = "Shirt Number: " + player.ShirtNumber;
            lblPosition.Text = "Position: " + player.Position;
            lblCaptain.Text = "Captain: " + (player.IsCaptain ? "Yes" : "No");
            lblFavorite.Text = "Favorite: " + (player.IsFavorite ? "Yes" : "No");
            lblGoals.Text = "Goals: " + player.GoalsScored;
            lblYellowCards.Text = "Yellow Cards: " + player.YellowCards;
            lblAppearances.Text = "Appearances: " + player.Appearances;
        }
    }
} 