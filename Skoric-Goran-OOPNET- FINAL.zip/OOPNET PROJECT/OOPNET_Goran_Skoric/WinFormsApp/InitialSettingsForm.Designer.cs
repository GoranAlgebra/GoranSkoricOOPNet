﻿namespace WinFormsApp
{
    partial class InitialSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CancelBtn = new Button();
            ConfirmBtn = new Button();
            LanguageLb = new Label();
            GenderLb = new Label();
            LanguageCb = new ComboBox();
            GenderCb = new ComboBox();
            SuspendLayout();
            // 
            // CancelBtn
            // 
            CancelBtn.Location = new Point(380, 229);
            CancelBtn.Name = "CancelBtn";
            CancelBtn.Size = new Size(94, 29);
            CancelBtn.TabIndex = 11;
            CancelBtn.Text = "Cancel";
            CancelBtn.UseVisualStyleBackColor = true;
            // 
            // ConfirmBtn
            // 
            ConfirmBtn.Location = new Point(218, 229);
            ConfirmBtn.Name = "ConfirmBtn";
            ConfirmBtn.Size = new Size(94, 29);
            ConfirmBtn.TabIndex = 10;
            ConfirmBtn.Text = "Confirm";
            ConfirmBtn.UseVisualStyleBackColor = true;
            // 
            // LanguageLb
            // 
            LanguageLb.AutoSize = true;
            LanguageLb.Font = new Font("Segoe UI", 12F);
            LanguageLb.Location = new Point(380, 141);
            LanguageLb.Name = "LanguageLb";
            LanguageLb.Size = new Size(154, 28);
            LanguageLb.TabIndex = 9;
            LanguageLb.Text = "Select Language";
            LanguageLb.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // GenderLb
            // 
            GenderLb.AutoSize = true;
            GenderLb.Font = new Font("Segoe UI", 12F);
            GenderLb.Location = new Point(380, 78);
            GenderLb.Name = "GenderLb";
            GenderLb.Size = new Size(133, 28);
            GenderLb.TabIndex = 8;
            GenderLb.Text = "Select Gender";
            GenderLb.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LanguageCb
            // 
            LanguageCb.DropDownStyle = ComboBoxStyle.DropDownList;
            LanguageCb.FormattingEnabled = true;
            LanguageCb.Items.AddRange(new object[] { "English", "Croatian" });
            LanguageCb.Location = new Point(161, 141);
            LanguageCb.Name = "LanguageCb";
            LanguageCb.Size = new Size(151, 28);
            LanguageCb.TabIndex = 7;
            // 
            // GenderCb
            // 
            GenderCb.DropDownStyle = ComboBoxStyle.DropDownList;
            GenderCb.FormattingEnabled = true;
            GenderCb.Items.AddRange(new object[] { "Men", "Women" });
            GenderCb.Location = new Point(161, 78);
            GenderCb.Name = "GenderCb";
            GenderCb.Size = new Size(151, 28);
            GenderCb.TabIndex = 6;
            // 
            // InitialSettingsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CancelBtn);
            Controls.Add(ConfirmBtn);
            Controls.Add(LanguageLb);
            Controls.Add(GenderLb);
            Controls.Add(LanguageCb);
            Controls.Add(GenderCb);
            Name = "InitialSettingsForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "InitialSettingsForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CancelBtn;
        private Button ConfirmBtn;
        private Label LanguageLb;
        private Label GenderLb;
        private ComboBox LanguageCb;
        private ComboBox GenderCb;
    }
}