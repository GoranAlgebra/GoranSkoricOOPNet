﻿using System;
using System.IO;
using System.Windows;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private readonly string settingsPath = "user_settings.txt";

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            bool settingsExist = File.Exists(settingsPath);
            bool mainWindowOpened = false;
            if (!settingsExist)
            {
                var settingsWindow = new InitialSettings();
                bool? result = settingsWindow.ShowDialog();
                if (result != true)
                {
                    Shutdown();
                    return;
                }
                // If MainWindow was opened from InitialSettings, do not open it again
                mainWindowOpened = true;
            }

            if (!mainWindowOpened)
            {
                // Read display setting from file
                string displaySetting = "1920x1080";
                if (File.Exists(settingsPath))
                {
                    foreach (var line in File.ReadAllLines(settingsPath))
                    {
                        if (line.StartsWith("Display="))
                        {
                            displaySetting = line.Substring("Display=".Length);
                            break;
                        }
                    }
                }

                var mainWindow = new MainWindow();
                // Apply display setting
                switch (displaySetting)
                {
                    case "1920x1080":
                        mainWindow.Width = 1920;
                        mainWindow.Height = 1080;
                        mainWindow.WindowState = WindowState.Normal;
                        break;
                    case "2560x1440":
                        mainWindow.Width = 2560;
                        mainWindow.Height = 1440;
                        mainWindow.WindowState = WindowState.Normal;
                        break;
                    case "1280x720":
                        mainWindow.Width = 1280;
                        mainWindow.Height = 720;
                        mainWindow.WindowState = WindowState.Normal;
                        break;
                    case "Fullscreen":
                        mainWindow.WindowState = WindowState.Maximized;
                        mainWindow.WindowStyle = WindowStyle.None;
                        break;
                    default:
                        mainWindow.Width = 1920;
                        mainWindow.Height = 1080;
                        mainWindow.WindowState = WindowState.Normal;
                        break;
                }
                mainWindow.Show();
            }
        }
    }
}
