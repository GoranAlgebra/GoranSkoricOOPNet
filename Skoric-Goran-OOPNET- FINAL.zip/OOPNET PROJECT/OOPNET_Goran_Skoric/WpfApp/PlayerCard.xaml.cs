using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.IO;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Runtime.CompilerServices;
using ClassLibrary.Helpers;

namespace WpfApp
{
    public partial class PlayerCard : UserControl, INotifyPropertyChanged
    {
        private bool _isSelected;
        private PlayerInfoModel _playerData;
        private string _teamName;

        public event PropertyChangedEventHandler PropertyChanged;
        public event RoutedEventHandler PlayerSelected;

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }

        public PlayerInfoModel PlayerData
        {
            get => _playerData;
            set
            {
                _playerData = value;
                if (value != null)
                {
                    SetPlayer(value.Name, value.ShirtNumber, GetImageFileName(value.Name));
                }
            }
        }

        public string TeamName
        {
            get => _teamName;
            set => _teamName = value;
        }

        public PlayerCard()
        {
            InitializeComponent();
            DataContext = this;
            
            // Add click handlers to make the entire card clickable
            this.PreviewMouseLeftButtonDown += PlayerCard_PreviewMouseLeftButtonDown;
            this.MouseLeftButtonDown += PlayerCard_MouseLeftButtonDown;
        }

        private void PlayerCard_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Handle the click event
            HandlePlayerClick();
            e.Handled = true;
        }

        private void PlayerCard_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Alternative click handler
            HandlePlayerClick();
        }

        private void HandlePlayerClick()
        {
            // Toggle selection state
            IsSelected = !IsSelected;
            
            // Raise the selection event
            PlayerSelected?.Invoke(this, new RoutedEventArgs());
        }

        public void SetPlayer(string name, int number, string imageFileName)
        {
            PlayerName.Text = name;
            PlayerNumber.Text = number.ToString();
            
            // Load player image
            LoadPlayerImage(imageFileName);
        }

        public void Deselect()
        {
            IsSelected = false;
        }

        private string GetImageFileName(string playerName)
        {
            // This method should be implemented to get the image filename for a player
            // For now, return null to use default image
            return null;
        }

        private void LoadPlayerImage(string imageFileName)
        {
            try
            {
                string imagePath = ImageHelper.GetPlayerImagePath(imageFileName);
                PlayerImage.Source = new BitmapImage(new System.Uri(imagePath));
            }
            catch
            {
                // If any error occurs, just leave the image empty
                PlayerImage.Source = null;
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
} 