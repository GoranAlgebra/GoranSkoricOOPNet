﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for TeamInfo.xaml
    /// </summary>
    public partial class TeamInfo : Window
    {
        private string _language = "English";

        public TeamInfo()
        {
            InitializeComponent();
        }

        public TeamInfo(string teamName, string teamCode, int gamesPlayed, int wins, int losses, int draws, int goalsFor, int goalsConceded, int goalDifference, string language = "English")
        {
            InitializeComponent();
            _language = language;
            
            // Apply language
            ApplyLanguage();
            
            LbTeamName_Code.Content = $"{teamName} ({teamCode})";
            LbGamePlayed_Data.Content = gamesPlayed.ToString();
            LbWins_Data.Content = wins.ToString();
            LbLosses_Data.Content = losses.ToString();
            LbDraws_Data.Content = draws.ToString();
            LbGoalsFor_Data.Content = goalsFor.ToString();
            LbGoalsConceded_Data.Content = goalsConceded.ToString();
            LbGoalsDifference_Data.Content = goalDifference.ToString();
        }

        private void ApplyLanguage()
        {
            if (_language == "Croatian")
            {
                this.Title = "Informacije o timu";
                LbGamePlayed.Content = "Odigrane utakmice:";
                LbWins.Content = "Pobjede:";
                LbLosses.Content = "Porazi:";
                LbDraws.Content = "Neriješeno:";
                LbGoalsFor.Content = "Postignuti golovi:";
                LbGoalsConceded.Content = "Primljeni golovi:";
                LbGoalsDifference.Content = "Razlika golova:";
            }
            else
            {
                this.Title = "Team Info";
                LbGamePlayed.Content = "Games Played:";
                LbWins.Content = "Wins:";
                LbLosses.Content = "Losses:";
                LbDraws.Content = "Draws:";
                LbGoalsFor.Content = "Goals Scored:";
                LbGoalsConceded.Content = "Goals Conceded:";
                LbGoalsDifference.Content = "Goals Difference:";
            }
        }

        private void DgTeamStats_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
