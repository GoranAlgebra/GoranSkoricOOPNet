﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary.Helpers;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for PlayerInfo.xaml
    /// </summary>
    public partial class PlayerInfo : Window
    {
        private string _language = "English";

        public PlayerInfo()
        {
            InitializeComponent();
        }

        public PlayerInfo(string name, int shirtNumber, string position, bool isCaptain, int goals, int yellowCards, string imageFileName = null, string language = "English")
        {
            InitializeComponent();
            _language = language;
            
            // Apply language
            ApplyLanguage();
            
            // Set labels (assume you will add them in XAML)
            LbPlayerName_Data.Content = name;
            LbPlayerNumber_Data.Content = shirtNumber.ToString();
            LbPlayerPosition_Data.Content = position;
            LbCaptain_Data.Content = isCaptain ? (_language == "Croatian" ? "Da" : "Yes") : (_language == "Croatian" ? "Ne" : "No");
            LbGoals_Data.Content = goals.ToString();
            LbYellowcards_Data.Content = yellowCards.ToString();
            
            // Load player image
            LoadPlayerImage(imageFileName);
        }

        private void ApplyLanguage()
        {
            if (_language == "Croatian")
            {
                this.Title = "Informacije o igraču";
                LbPlayerName.Content = "Ime igrača: ";
                LbPlayerNumber.Content = "Broj igrača: ";
                LbPlayerPosition.Content = "Pozicija igrača: ";
                LbCaptain.Content = "Kapetan tima: ";
                LbGoals.Content = "Golovi u ovoj utakmici: ";
                LbYellowCards.Content = "Žuti kartoni u ovoj utakmici: ";
            }
            else
            {
                this.Title = "Player Info";
                LbPlayerName.Content = "Player Name: ";
                LbPlayerNumber.Content = "Player Number: ";
                LbPlayerPosition.Content = "Player Position: ";
                LbCaptain.Content = "Player Captain: ";
                LbGoals.Content = "Player Goals This Match: ";
                LbYellowCards.Content = "Yellow Cards This Match: ";
            }
        }

        private void LoadPlayerImage(string imageFileName)
        {
            try
            {
                string imagePath = ImageHelper.GetPlayerImagePath(imageFileName);
                ImgPlayerImg.Source = new BitmapImage(new System.Uri(imagePath));
            }
            catch
            {
                // If any error occurs, just leave the image empty
                ImgPlayerImg.Source = null;
            }
        }
    }
}
