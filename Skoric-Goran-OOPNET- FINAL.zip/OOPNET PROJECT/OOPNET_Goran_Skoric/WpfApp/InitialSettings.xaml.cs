﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for InitialSettings.xaml
    /// </summary>
    public partial class InitialSettings : Window
    {
        private readonly string settingsPath = "user_settings.txt";
        private bool isLoading = false;

        public InitialSettings()
        {
            InitializeComponent();
            PopulateComboBoxes();
            BtnConfirm.Click += BtnConfirm_Click;
            BtnCancel.Click += BtnCancel_Click;
        }

        private void PopulateComboBoxes()
        {
            CbSelectGender.ItemsSource = new string[] { "Male", "Female" };
            CbSelectGender.SelectedIndex = 0;
            CbSelectLang.ItemsSource = new string[] { "English", "Croatian" };
            CbSelectLang.SelectedIndex = 0;
            CbSelectDisplay.ItemsSource = new string[] { "1920x1080", "2560x1440", "1280x720", "Fullscreen" };
            CbSelectDisplay.SelectedIndex = 0;
        }

        private async void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (isLoading) return;

            if (CbSelectGender.SelectedItem == null || CbSelectLang.SelectedItem == null || CbSelectDisplay.SelectedItem == null)
            {
                MessageBox.Show("Please select all options before proceeding.", "Incomplete Settings", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                SetLoadingState(true);
                await SaveSettingsAsync(
                    CbSelectGender.SelectedItem.ToString(),
                    CbSelectLang.SelectedItem.ToString(),
                    CbSelectDisplay.SelectedItem.ToString()
                );
                // Force open MainWindow before closing InitialSettings
                var mainWindow = new MainWindow();
                mainWindow.Show();
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.DialogResult = true;
                }));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (isLoading) return;
            this.DialogResult = false;
            this.Close();
        }

        private async Task SaveSettingsAsync(string gender, string language, string display)
        {
            string[] settings = new string[]
            {
                $"Gender={gender}",
                $"Language={language}",
                $"Display={display}"
            };
            await File.WriteAllLinesAsync(settingsPath, settings);
        }

        private void SetLoadingState(bool loading)
        {
            isLoading = loading;
            BtnConfirm.IsEnabled = !loading;
            BtnCancel.IsEnabled = !loading;
            CbSelectGender.IsEnabled = !loading;
            CbSelectLang.IsEnabled = !loading;
            CbSelectDisplay.IsEnabled = !loading;
            BtnConfirm.Content = loading ? "Saving..." : "Confirm";
        }
    }
}
