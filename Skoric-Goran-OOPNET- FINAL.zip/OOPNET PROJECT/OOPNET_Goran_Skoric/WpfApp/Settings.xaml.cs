﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for Settings.xaml
    /// </summary>
    public partial class Settings : Window
    {
        private readonly string settingsPath = "user_settings.txt";
        private bool isLoading = false;

        public Settings()
        {
            InitializeComponent();
            PopulateComboBoxes();
            LoadCurrentSettings();
            BtnConfirm.Click += BtnConfirm_Click;
            BtnCancel.Click += BtnCancel_Click;
        }

        private void PopulateComboBoxes()
        {
            CbSelectGender.ItemsSource = new string[] { "Male", "Female" };
            CbSelectLang.ItemsSource = new string[] { "English", "Croatian" };
            CbSelectDisplay.ItemsSource = new string[] { "1920x1080", "2560x1440", "1280x720", "Fullscreen" };
        }

        private void LoadCurrentSettings()
        {
            if (!File.Exists(settingsPath))
            {
                CbSelectGender.SelectedIndex = 0;
                CbSelectLang.SelectedIndex = 0;
                CbSelectDisplay.SelectedIndex = 0;
                return;
            }
            string gender = "Male";
            string language = "English";
            string display = "1920x1080";
            foreach (var line in File.ReadAllLines(settingsPath))
            {
                if (line.StartsWith("Gender="))
                    gender = line.Substring("Gender=".Length);
                else if (line.StartsWith("Language="))
                    language = line.Substring("Language=".Length);
                else if (line.StartsWith("Display="))
                    display = line.Substring("Display=".Length);
            }
            CbSelectGender.SelectedItem = gender;
            CbSelectLang.SelectedItem = language;
            CbSelectDisplay.SelectedItem = display;
        }

        private async void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (isLoading) return;
            if (CbSelectGender.SelectedItem == null || CbSelectLang.SelectedItem == null || CbSelectDisplay.SelectedItem == null)
            {
                MessageBox.Show("Please select all options before proceeding.", "Incomplete Settings", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                SetLoadingState(true);
                await SaveSettingsAsync(
                    CbSelectGender.SelectedItem.ToString(),
                    CbSelectLang.SelectedItem.ToString(),
                    CbSelectDisplay.SelectedItem.ToString()
                );
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (isLoading) return;
            this.DialogResult = false;
            this.Close();
        }

        private async Task SaveSettingsAsync(string gender, string language, string display)
        {
            string[] settings = new string[]
            {
                $"Gender={gender}",
                $"Language={language}",
                $"Display={display}"
            };
            await File.WriteAllLinesAsync(settingsPath, settings);
        }

        private void SetLoadingState(bool loading)
        {
            isLoading = loading;
            BtnConfirm.IsEnabled = !loading;
            BtnCancel.IsEnabled = !loading;
            CbSelectGender.IsEnabled = !loading;
            CbSelectLang.IsEnabled = !loading;
            CbSelectDisplay.IsEnabled = !loading;
            BtnConfirm.Content = loading ? "Saving..." : "Confirm";
        }
    }
}
