﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text.Json;
using ClassLibrary.Services;
using ClassLibrary.Models;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly WorldCupService _worldCupService = new WorldCupService();
        private JsonElement _currentWorldCupData;
        private string _currentGender = "Men";
        private string _currentLanguage = "English";
        private List<MatchInfo> _currentMatchData = new List<MatchInfo>();
        private Dictionary<string, PlayerData> _allPlayers = new Dictionary<string, PlayerData>();
        private PlayerInfoModel _selectedPlayer;
        private string _selectedPlayerTeam;
        private MatchInfo _selectedPlayerMatch;
        private List<PlayerCard> _allPlayerCards = new List<PlayerCard>();
        private MatchInfo _currentDisplayedMatch; // Track the currently displayed match

        public MainWindow()
        {
            InitializeComponent();
            BtnSettings.Click += BtnSettings_Click;
            CbYourTeam.SelectionChanged += CbYourTeam_SelectionChanged;
            CbOtherTeam.SelectionChanged += CbOtherTeam_SelectionChanged;
            this.Loaded += MainWindow_Loaded;
            BtnYourTeamInfo.Click += BtnYourTeamInfo_Click;
            BtnOtherTeamInfo.Click += BtnOtherTeamInfo_Click;
            BtnPlayerInfo.Click += BtnPlayerInfo_Click;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            string gender = "Men";
            string language = "English";
            string settingsPath = "user_settings.txt";
            if (File.Exists(settingsPath))
            {
                foreach (var line in File.ReadAllLines(settingsPath))
                {
                    if (line.StartsWith("Gender="))
                    {
                        gender = line.Substring("Gender=".Length);
                    }
                    else if (line.StartsWith("Language="))
                    {
                        language = line.Substring("Language=".Length);
                    }
                }
            }
            _currentGender = gender;
            _currentLanguage = language;
            ApplyLanguage();
            await LoadTeamsForComboBox(gender);
        }

        private async Task LoadTeamsForComboBox(string gender)
        {
            if (gender == "Female" || gender == "Women")
                _currentWorldCupData = await _worldCupService.LoadWomenWorldCupDataJsonElement();
            else
                _currentWorldCupData = await _worldCupService.LoadMenWorldCupDataJsonElement();

            // Load player data after loading world cup data
            await LoadPlayerData();

            var teams = new List<string>();
            if (_currentWorldCupData.TryGetProperty("Teams", out JsonElement teamsElement) && teamsElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var team in teamsElement.EnumerateArray())
                {
                    if (team.TryGetProperty("country", out JsonElement countryElement) && countryElement.ValueKind == JsonValueKind.String &&
                        team.TryGetProperty("fifa_code", out JsonElement fifaCodeElement) && fifaCodeElement.ValueKind == JsonValueKind.String)
                    {
                        string name = countryElement.GetString();
                        string fifaCode = fifaCodeElement.GetString();
                        teams.Add($"{name} ({fifaCode})");
                    }
                }
            }
            teams = teams.OrderBy(t => t).ToList();
            CbYourTeam.ItemsSource = teams;
        }

        private async Task LoadPlayerData()
        {
            try
            {
                string playersFilePath = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Data", 
                    _currentGender == "Female" || _currentGender == "Women" ? "Female" : "Male", 
                    _currentGender == "Female" || _currentGender == "Women" ? "women_players.json" : "men_players.json");

                if (File.Exists(playersFilePath))
                {
                    string json = await File.ReadAllTextAsync(playersFilePath);
                    var teams = JsonSerializer.Deserialize<List<TeamPlayers>>(json);
                    
                    _allPlayers.Clear();
                    foreach (var team in teams)
                    {
                        foreach (var player in team.Players)
                        {
                            string key = $"{player.FullName}_{team.TeamName}";
                            _allPlayers[key] = new PlayerData
                            {
                                Name = player.FullName,
                                ShirtNumber = player.ShirtNumber,
                                ImageFileName = player.ImageFileName,
                                TeamName = team.TeamName
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading player data: {ex.Message}");
            }
        }

        private async void CbYourTeam_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CbYourTeam.SelectedItem == null)
            {
                CbOtherTeam.ItemsSource = null;
                TbScoreline.Text = _currentLanguage == "Croatian" ? "Odaberite timove za rezultat" : "Select Teams To Get A Scoreline";
                return;
            }

            string selectedTeam = CbYourTeam.SelectedItem.ToString();
            string fifaCode = ExtractFifaCode(selectedTeam);
            
            if (string.IsNullOrEmpty(fifaCode))
                return;

            await LoadOpponentTeams(fifaCode);
        }

        private string ExtractFifaCode(string teamDisplay)
        {
            // Extract FIFA code from "Country (FIFA_CODE)" format
            int startIndex = teamDisplay.LastIndexOf('(');
            int endIndex = teamDisplay.LastIndexOf(')');
            if (startIndex != -1 && endIndex != -1 && endIndex > startIndex)
            {
                return teamDisplay.Substring(startIndex + 1, endIndex - startIndex - 1);
            }
            return string.Empty;
        }

        private async Task LoadOpponentTeams(string yourTeamFifaCode)
        {
            var opponentTeams = new HashSet<string>();
            var matchData = new List<MatchInfo>();

            if (_currentWorldCupData.TryGetProperty("Matches", out JsonElement matchesElement) && matchesElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var match in matchesElement.EnumerateArray())
                {
                    string homeTeamFifaCode = "";
                    string awayTeamFifaCode = "";
                    string homeTeamName = "";
                    string awayTeamName = "";

                    // Extract home team info
                    if (match.TryGetProperty("home_team", out JsonElement homeTeam) && 
                        homeTeam.TryGetProperty("code", out JsonElement homeCode) && homeCode.ValueKind == JsonValueKind.String)
                    {
                        homeTeamFifaCode = homeCode.GetString();
                        if (match.TryGetProperty("home_team_statistics", out JsonElement homeStats) &&
                            homeStats.TryGetProperty("country", out JsonElement homeCountry) && homeCountry.ValueKind == JsonValueKind.String)
                        {
                            homeTeamName = homeCountry.GetString();
                        }
                    }

                    // Extract away team info
                    if (match.TryGetProperty("away_team", out JsonElement awayTeam) && 
                        awayTeam.TryGetProperty("code", out JsonElement awayCode) && awayCode.ValueKind == JsonValueKind.String)
                    {
                        awayTeamFifaCode = awayCode.GetString();
                        if (match.TryGetProperty("away_team_statistics", out JsonElement awayStats) &&
                            awayStats.TryGetProperty("country", out JsonElement awayCountry) && awayCountry.ValueKind == JsonValueKind.String)
                        {
                            awayTeamName = awayCountry.GetString();
                        }
                    }

                    // Check if your team played in this match
                    if (homeTeamFifaCode == yourTeamFifaCode || awayTeamFifaCode == yourTeamFifaCode)
                    {
                        // Add opponent to the list
                        string opponentFifaCode = homeTeamFifaCode == yourTeamFifaCode ? awayTeamFifaCode : homeTeamFifaCode;
                        string opponentName = homeTeamFifaCode == yourTeamFifaCode ? awayTeamName : homeTeamName;
                        
                        if (!string.IsNullOrEmpty(opponentFifaCode) && !string.IsNullOrEmpty(opponentName))
                        {
                            opponentTeams.Add($"{opponentName} ({opponentFifaCode})");
                        }

                        // Parse match data
                        var matchInfo = ParseMatchData(match, yourTeamFifaCode, homeTeamFifaCode, awayTeamFifaCode, homeTeamName, awayTeamName);
                        if (matchInfo != null)
                        {
                            matchData.Add(matchInfo);
                        }
                    }
                }
            }

            // Store match data for later use
            _currentMatchData = matchData;

            // Populate opponent teams dropdown
            var sortedOpponents = opponentTeams.OrderBy(t => t).ToList();
            CbOtherTeam.ItemsSource = sortedOpponents;
        }

        private MatchInfo ParseMatchData(JsonElement match, string yourTeamFifaCode, string homeTeamFifaCode, string awayTeamFifaCode, string homeTeamName, string awayTeamName)
        {
            try
            {
                var matchInfo = new MatchInfo
                {
                    HomeTeam = homeTeamName,
                    AwayTeam = awayTeamName,
                    HomeTeamFifaCode = homeTeamFifaCode,
                    AwayTeamFifaCode = awayTeamFifaCode,
                    IsYourTeamHome = homeTeamFifaCode == yourTeamFifaCode
                };

                // Parse score
                if (match.TryGetProperty("home_team", out JsonElement homeTeam) &&
                    homeTeam.TryGetProperty("goals", out JsonElement homeGoals) && homeGoals.ValueKind == JsonValueKind.Number)
                {
                    matchInfo.HomeScore = homeGoals.GetInt32();
                }

                if (match.TryGetProperty("away_team", out JsonElement awayTeam) &&
                    awayTeam.TryGetProperty("goals", out JsonElement awayGoals) && awayGoals.ValueKind == JsonValueKind.Number)
                {
                    matchInfo.AwayScore = awayGoals.GetInt32();
                }

                // Parse starting elevens
                if (match.TryGetProperty("home_team_statistics", out JsonElement homeStats) &&
                    homeStats.TryGetProperty("starting_eleven", out JsonElement homeStartingEleven) && 
                    homeStartingEleven.ValueKind == JsonValueKind.Array)
                {
                    matchInfo.HomeStartingEleven = ParseStartingEleven(homeStartingEleven);
                }

                if (match.TryGetProperty("away_team_statistics", out JsonElement awayStats) &&
                    awayStats.TryGetProperty("starting_eleven", out JsonElement awayStartingEleven) && 
                    awayStartingEleven.ValueKind == JsonValueKind.Array)
                {
                    matchInfo.AwayStartingEleven = ParseStartingEleven(awayStartingEleven);
                }

                // Parse tactics
                if (match.TryGetProperty("home_team_statistics", out JsonElement homeStatsTactics) &&
                    homeStatsTactics.TryGetProperty("tactics", out JsonElement homeTacticsElem) && homeTacticsElem.ValueKind == JsonValueKind.String)
                {
                    matchInfo.HomeTactics = homeTacticsElem.GetString();
                }
                if (match.TryGetProperty("away_team_statistics", out JsonElement awayStatsTactics) &&
                    awayStatsTactics.TryGetProperty("tactics", out JsonElement awayTacticsElem) && awayTacticsElem.ValueKind == JsonValueKind.String)
                {
                    matchInfo.AwayTactics = awayTacticsElem.GetString();
                }

                // Parse home team events
                if (match.TryGetProperty("home_team_events", out JsonElement homeEvents) && homeEvents.ValueKind == JsonValueKind.Array)
                {
                    matchInfo.HomeTeamEvents = ParseMatchEvents(homeEvents);
                }

                // Parse away team events
                if (match.TryGetProperty("away_team_events", out JsonElement awayEvents) && awayEvents.ValueKind == JsonValueKind.Array)
                {
                    matchInfo.AwayTeamEvents = ParseMatchEvents(awayEvents);
                }

                return matchInfo;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error parsing match data: {ex.Message}");
                return null;
            }
        }

        private List<MatchEvent> ParseMatchEvents(JsonElement eventsElement)
        {
            var events = new List<MatchEvent>();
            
            foreach (var eventElement in eventsElement.EnumerateArray())
            {
                try
                {
                    var matchEvent = new MatchEvent();

                    if (eventElement.TryGetProperty("id", out JsonElement idElement) && idElement.ValueKind == JsonValueKind.Number)
                    {
                        matchEvent.Id = idElement.GetInt32();
                    }

                    if (eventElement.TryGetProperty("type_of_event", out JsonElement typeElement) && typeElement.ValueKind == JsonValueKind.String)
                    {
                        matchEvent.TypeOfEvent = typeElement.GetString();
                    }

                    if (eventElement.TryGetProperty("player", out JsonElement playerElement) && playerElement.ValueKind == JsonValueKind.String)
                    {
                        matchEvent.Player = playerElement.GetString();
                    }

                    if (eventElement.TryGetProperty("time", out JsonElement timeElement) && timeElement.ValueKind == JsonValueKind.String)
                    {
                        matchEvent.Time = timeElement.GetString();
                    }

                    events.Add(matchEvent);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error parsing match event: {ex.Message}");
                }
            }

            return events;
        }

        private List<PlayerInfoModel> ParseStartingEleven(JsonElement startingElevenElement)
        {
            var players = new List<PlayerInfoModel>();
            
            foreach (var playerElement in startingElevenElement.EnumerateArray())
            {
                try
                {
                    var player = new PlayerInfoModel();

                    if (playerElement.TryGetProperty("name", out JsonElement nameElement) && nameElement.ValueKind == JsonValueKind.String)
                    {
                        player.Name = nameElement.GetString();
                    }

                    if (playerElement.TryGetProperty("position", out JsonElement positionElement) && positionElement.ValueKind == JsonValueKind.String)
                    {
                        string position = positionElement.GetString();
                        player.Position = ConvertPosition(position);
                    }

                    if (playerElement.TryGetProperty("shirt_number", out JsonElement shirtNumberElement) && shirtNumberElement.ValueKind == JsonValueKind.Number)
                    {
                        player.ShirtNumber = shirtNumberElement.GetInt32();
                    }

                    if (playerElement.TryGetProperty("captain", out JsonElement captainElement) && captainElement.ValueKind == JsonValueKind.True)
                    {
                        player.IsCaptain = true;
                    }

                    players.Add(player);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error parsing player: {ex.Message}");
                }
            }

            return players;
        }

        private string ConvertPosition(string apiPosition)
        {
            return apiPosition.ToLower() switch
            {
                "goalkeeper" => "Goalie",
                "defender" => "Defender",
                "midfielder" => "Midfield",
                "forward" => "Forward",
                _ => apiPosition
            };
        }

        private void BtnSettings_Click(object sender, RoutedEventArgs e)
        {
            var settingsWindow = new Settings();
            bool? result = settingsWindow.ShowDialog();
            if (result == true)
            {
                string displaySetting = "1920x1080";
                string languageSetting = "English";
                string genderSetting = "Men";
                string settingsPath = "user_settings.txt";
                if (File.Exists(settingsPath))
                {
                    foreach (var line in File.ReadAllLines(settingsPath))
                    {
                        if (line.StartsWith("Display="))
                            displaySetting = line.Substring("Display=".Length);
                        else if (line.StartsWith("Language="))
                            languageSetting = line.Substring("Language=".Length);
                        else if (line.StartsWith("Gender="))
                            genderSetting = line.Substring("Gender=".Length);
                    }
                }

                switch (displaySetting)
                {
                    case "1920x1080":
                        this.Width = 1920;
                        this.Height = 1080;
                        this.WindowState = WindowState.Normal;
                        this.WindowStyle = WindowStyle.SingleBorderWindow;
                        break;
                    case "2560x1440":
                        this.Width = 2560;
                        this.Height = 1440;
                        this.WindowState = WindowState.Normal;
                        this.WindowStyle = WindowStyle.SingleBorderWindow;
                        break;
                    case "1280x720":
                        this.Width = 1280;
                        this.Height = 720;
                        this.WindowState = WindowState.Normal;
                        this.WindowStyle = WindowStyle.SingleBorderWindow;
                        break;
                    case "Fullscreen":
                        this.WindowState = WindowState.Maximized;
                        this.WindowStyle = WindowStyle.None;
                        break;
                    default:
                        this.Width = 1920;
                        this.Height = 1080;
                        this.WindowState = WindowState.Normal;
                        this.WindowStyle = WindowStyle.SingleBorderWindow;
                        break;
                }

                // Reload language if changed
                if (languageSetting != _currentLanguage)
                {
                    _currentLanguage = languageSetting;
                    ApplyLanguage();
                }

                // Reload teams if gender changed
                if (genderSetting != _currentGender)
                {
                    _currentGender = genderSetting;
                    _ = LoadTeamsForComboBox(genderSetting);
                }
            }
        }

        private void ApplyLanguage()
        {
            if (_currentLanguage == "Croatian")
            {
                // Window title
                this.Title = "Svjetsko prvenstvo u nogometu";
                
                // Labels
                LbYourTeam.Content = "Odaberite vaš tim";
                LbOtherTeam.Content = "Odaberite protivnički tim";
                
                // Buttons
                BtnYourTeamInfo.Content = "Informacije o vašem timu";
                BtnOtherTeamInfo.Content = "Informacije o protivničkom timu";
                BtnPlayerInfo.Content = "Informacije o igraču";
                BtnSettings.Content = "Postavke";
                
                // Default text
                TbScoreline.Text = "Odaberite timove za rezultat";
            }
            else // English or default
            {
                // Window title
                this.Title = "World Cup Football";
                
                // Labels
                LbYourTeam.Content = "Select Your Team";
                LbOtherTeam.Content = "Select Other Team";
                
                // Buttons
                BtnYourTeamInfo.Content = "See Your Teams Information";
                BtnOtherTeamInfo.Content = "See Other Teams Information";
                BtnPlayerInfo.Content = "See Player Info";
                BtnSettings.Content = "Settings";
                
                // Default text
                TbScoreline.Text = "Select Teams To Get A Scoreline";
            }
        }

        private void CbOtherTeam_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CbOtherTeam.SelectedItem == null || CbYourTeam.SelectedItem == null)
            {
                TbScoreline.Text = _currentLanguage == "Croatian" ? "Odaberite timove za rezultat" : "Select Teams To Get A Scoreline";
                ClearPlayerGrids();
                return;
            }

            string yourTeam = CbYourTeam.SelectedItem.ToString();
            string otherTeam = CbOtherTeam.SelectedItem.ToString();
            
            string yourTeamFifaCode = ExtractFifaCode(yourTeam);
            string otherTeamFifaCode = ExtractFifaCode(otherTeam);

            // Find the match between these two teams
            var match = _currentMatchData.FirstOrDefault(m => 
                (m.HomeTeamFifaCode == yourTeamFifaCode && m.AwayTeamFifaCode == otherTeamFifaCode) ||
                (m.HomeTeamFifaCode == otherTeamFifaCode && m.AwayTeamFifaCode == yourTeamFifaCode));

            if (match != null)
            {
                DisplayMatchInfo(match, yourTeamFifaCode);
                PopulatePlayerGrids(match, yourTeamFifaCode);
            }
            else
            {
                string noMatchText = _currentLanguage == "Croatian" ? 
                    $"Nije pronađena utakmica između {yourTeam} i {otherTeam}" :
                    $"No match found between {yourTeam} and {otherTeam}";
                TbScoreline.Text = noMatchText;
                ClearPlayerGrids();
            }
        }

        private void DisplayMatchInfo(MatchInfo match, string yourTeamFifaCode)
        {
            string yourTeamName = match.HomeTeamFifaCode == yourTeamFifaCode ? match.HomeTeam : match.AwayTeam;
            string otherTeamName = match.HomeTeamFifaCode == yourTeamFifaCode ? match.AwayTeam : match.HomeTeam;
            
            int yourScore = match.HomeTeamFifaCode == yourTeamFifaCode ? match.HomeScore : match.AwayScore;
            int otherScore = match.HomeTeamFifaCode == yourTeamFifaCode ? match.AwayScore : match.HomeScore;

            string result;
            if (_currentLanguage == "Croatian")
            {
                result = yourScore > otherScore ? "POBJEDA" : yourScore < otherScore ? "PORAZ" : "NERIJEŠENO";
            }
            else
            {
                result = yourScore > otherScore ? "WIN" : yourScore < otherScore ? "LOSS" : "DRAW";
            }
            
            TbScoreline.Text = $"({result}) {yourTeamName} {yourScore} - {otherScore} {otherTeamName}";
        }

        private void ClearPlayerGrids()
        {
            // Clear all player cards and reset selection
            _allPlayerCards.Clear();
            _selectedPlayer = null;
            _selectedPlayerTeam = null;
            _selectedPlayerMatch = null;
            
            YourGoaliesPanel.Children.Clear();
            YourDefendersPanel.Children.Clear();
            YourMidfieldersPanel.Children.Clear();
            YourForwardsPanel.Children.Clear();
            OtherGoaliesPanel.Children.Clear();
            OtherDefendersPanel.Children.Clear();
            OtherMidfieldersPanel.Children.Clear();
            OtherForwardsPanel.Children.Clear();
        }

        private void PopulatePlayerGrids(MatchInfo match, string yourTeamFifaCode)
        {
            ClearPlayerGrids();

            var yourTeamPlayers = match.HomeTeamFifaCode == yourTeamFifaCode ? match.HomeStartingEleven : match.AwayStartingEleven;
            var otherTeamPlayers = match.HomeTeamFifaCode == yourTeamFifaCode ? match.AwayStartingEleven : match.HomeStartingEleven;
            string yourTeamName = match.HomeTeamFifaCode == yourTeamFifaCode ? match.HomeTeam : match.AwayTeam;
            string otherTeamName = match.HomeTeamFifaCode == yourTeamFifaCode ? match.AwayTeam : match.HomeTeam;
            string yourTactics = match.HomeTeamFifaCode == yourTeamFifaCode ? match.HomeTactics : match.AwayTactics;
            string otherTactics = match.HomeTeamFifaCode == yourTeamFifaCode ? match.AwayTactics : match.HomeTactics;

            // Left team: Goalie, Defenders, Mids, Forwards
            PopulateTeamGrid(
                yourTeamPlayers, yourTeamName,
                YourGoaliesPanel, YourDefendersPanel, YourMidfieldersPanel, YourForwardsPanel, false);
            // Right team: Forwards, Mids, Defenders, Goalie (mirrored)
            PopulateTeamGrid(
                otherTeamPlayers, otherTeamName,
                OtherGoaliesPanel, OtherDefendersPanel, OtherMidfieldersPanel, OtherForwardsPanel, true);

            _currentDisplayedMatch = match;
        }

        private void PopulateTeamGrid(
            List<PlayerInfoModel> players,
            string teamName,
            StackPanel goaliesPanel,
            StackPanel defendersPanel,
            StackPanel midsPanel,
            StackPanel forwardsPanel,
            bool flip = false)
        {
            goaliesPanel.Children.Clear();
            defendersPanel.Children.Clear();
            midsPanel.Children.Clear();
            forwardsPanel.Children.Clear();

            var goalies = players.Where(p => p.Position == "Goalie").ToList();
            var defenders = players.Where(p => p.Position == "Defender").ToList();
            var mids = players.Where(p => p.Position == "Midfield").ToList();
            var forwards = players.Where(p => p.Position == "Forward").ToList();

            if (!flip)
            {
                foreach (var p in goalies) goaliesPanel.Children.Add(CreatePlayerCard(p, teamName));
                foreach (var p in defenders) defendersPanel.Children.Add(CreatePlayerCard(p, teamName));
                foreach (var p in mids) midsPanel.Children.Add(CreatePlayerCard(p, teamName));
                foreach (var p in forwards) forwardsPanel.Children.Add(CreatePlayerCard(p, teamName));
            }
            else
            {
                foreach (var p in forwards) forwardsPanel.Children.Add(CreatePlayerCard(p, teamName));
                foreach (var p in mids) midsPanel.Children.Add(CreatePlayerCard(p, teamName));
                foreach (var p in defenders) defendersPanel.Children.Add(CreatePlayerCard(p, teamName));
                foreach (var p in goalies) goaliesPanel.Children.Add(CreatePlayerCard(p, teamName));
            }
        }

        private PlayerCard CreatePlayerCard(PlayerInfoModel player, string teamName)
        {
            var playerCard = new PlayerCard();
            playerCard.Width = 140;
            playerCard.Height = 300;
            playerCard.TeamName = teamName;
            playerCard.PlayerData = player;
            
            string playerKey = $"{player.Name}_{teamName}";
            string imageFileName = "";
            if (_allPlayers.TryGetValue(playerKey, out PlayerData playerData))
            {
                imageFileName = playerData.ImageFileName;
                playerCard.SetPlayer(player.Name, player.ShirtNumber, imageFileName);
            }
            else
            {
                playerCard.SetPlayer(player.Name, player.ShirtNumber, null);
            }
            
            // Subscribe to player selection event
            playerCard.PlayerSelected += PlayerCard_PlayerSelected;
            
            // Store reference to the card
            _allPlayerCards.Add(playerCard);
            
            return playerCard;
        }

        private void PlayerCard_PlayerSelected(object sender, RoutedEventArgs e)
        {
            var selectedCard = sender as PlayerCard;
            if (selectedCard == null) return;

            // If Ctrl is not pressed, deselect all other cards
            if (!Keyboard.IsKeyDown(Key.LeftCtrl) && !Keyboard.IsKeyDown(Key.RightCtrl))
            {
                DeselectAllPlayerCards();
                selectedCard.IsSelected = true;
            }

            // Update selected player info
            _selectedPlayer = selectedCard.PlayerData;
            _selectedPlayerTeam = GetTeamNameForPlayerInCurrentMatch(selectedCard.PlayerData);
            _selectedPlayerMatch = _currentDisplayedMatch;
        }

        private void DeselectAllPlayerCards()
        {
            foreach (var card in _allPlayerCards)
            {
                card.Deselect();
            }
        }

        private string GetTeamNameForPlayerInCurrentMatch(PlayerInfoModel player)
        {
            if (_currentDisplayedMatch == null) return string.Empty;

            // Check if player is in home team
            if (_currentDisplayedMatch.HomeStartingEleven.Any(p => p.Name == player.Name && p.ShirtNumber == player.ShirtNumber))
            {
                return _currentDisplayedMatch.HomeTeam;
            }
            
            // Check if player is in away team
            if (_currentDisplayedMatch.AwayStartingEleven.Any(p => p.Name == player.Name && p.ShirtNumber == player.ShirtNumber))
            {
                return _currentDisplayedMatch.AwayTeam;
            }

            return string.Empty;
        }

        private (int gamesPlayed, int wins, int losses, int draws, int goalsFor, int goalsConceded, int goalDifference) GetTeamStats(string teamCode)
        {
            int gamesPlayed = 0, wins = 0, losses = 0, draws = 0, goalsFor = 0, goalsConceded = 0;
            if (_currentWorldCupData.TryGetProperty("Matches", out JsonElement matchesElement) && matchesElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var match in matchesElement.EnumerateArray())
                {
                    string homeCode = match.GetProperty("home_team").GetProperty("code").GetString();
                    string awayCode = match.GetProperty("away_team").GetProperty("code").GetString();
                    int homeGoals = match.GetProperty("home_team").GetProperty("goals").GetInt32();
                    int awayGoals = match.GetProperty("away_team").GetProperty("goals").GetInt32();
                    if (homeCode == teamCode || awayCode == teamCode)
                    {
                        gamesPlayed++;
                        bool isHome = homeCode == teamCode;
                        int goalsScored = isHome ? homeGoals : awayGoals;
                        int goalsAgainst = isHome ? awayGoals : homeGoals;
                        goalsFor += goalsScored;
                        goalsConceded += goalsAgainst;
                        if (goalsScored > goalsAgainst) wins++;
                        else if (goalsScored < goalsAgainst) losses++;
                        else draws++;
                    }
                }
            }
            int goalDifference = goalsFor - goalsConceded;
            return (gamesPlayed, wins, losses, draws, goalsFor, goalsConceded, goalDifference);
        }

        private void BtnYourTeamInfo_Click(object sender, RoutedEventArgs e)
        {
            if (CbYourTeam.SelectedItem != null)
            {
                string selected = CbYourTeam.SelectedItem.ToString();
                string name = selected.Substring(0, selected.LastIndexOf("("))?.Trim();
                string code = ExtractFifaCode(selected);
                var stats = GetTeamStats(code);
                var teamInfoWindow = new TeamInfo(name, code, stats.gamesPlayed, stats.wins, stats.losses, stats.draws, stats.goalsFor, stats.goalsConceded, stats.goalDifference, _currentLanguage);
                teamInfoWindow.ShowDialog();
            }
        }

        private void BtnOtherTeamInfo_Click(object sender, RoutedEventArgs e)
        {
            if (CbOtherTeam.SelectedItem != null)
            {
                string selected = CbOtherTeam.SelectedItem.ToString();
                string name = selected.Substring(0, selected.LastIndexOf("("))?.Trim();
                string code = ExtractFifaCode(selected);
                var stats = GetTeamStats(code);
                var teamInfoWindow = new TeamInfo(name, code, stats.gamesPlayed, stats.wins, stats.losses, stats.draws, stats.goalsFor, stats.goalsConceded, stats.goalDifference, _currentLanguage);
                teamInfoWindow.ShowDialog();
            }
        }

        private void BtnPlayerInfo_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedPlayer != null && _selectedPlayerMatch != null)
            {
                int goals = 0;
                int yellowCards = 0;

                // Count goals and yellow cards from match events
                var allEvents = _selectedPlayerMatch.HomeTeamEvents.Concat(_selectedPlayerMatch.AwayTeamEvents);
                
                foreach (var matchEvent in allEvents)
                {
                    if (matchEvent.Player == _selectedPlayer.Name)
                    {
                        switch (matchEvent.TypeOfEvent)
                        {
                            case "goal":
                            case "goal-penalty":
                                goals++;
                                break;
                            case "yellow-card":
                            case "yellow-card-second":
                                yellowCards++;
                                break;
                        }
                    }
                }

                // Get player image filename from the loaded player data
                string imageFileName = null;
                string playerKey = $"{_selectedPlayer.Name}_{_selectedPlayerTeam}";
                if (_allPlayers.TryGetValue(playerKey, out PlayerData playerData))
                {
                    imageFileName = playerData.ImageFileName;
                }

                var playerInfoWindow = new PlayerInfo(
                    _selectedPlayer.Name,
                    _selectedPlayer.ShirtNumber,
                    _selectedPlayer.Position,
                    _selectedPlayer.IsCaptain,
                    goals,
                    yellowCards,
                    imageFileName,
                    _currentLanguage
                );
                playerInfoWindow.ShowDialog();
            }
            else
            {
                string message = _currentLanguage == "Croatian" ? 
                    "Molimo odaberite igrača na terenu prvo." : 
                    "Please select a player on the field first.";
                MessageBox.Show(message);
            }
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.Key == Key.Escape)
            {
                // Just close the window; confirmation will be handled in OnClosing
                this.Close();
            }
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            // Only show confirmation if this is not already a confirmed exit
            if (!e.Cancel)
            {
                string message = _currentLanguage == "Croatian" ? 
                    "Jeste li sigurni da želite izaći iz programa?" : 
                    "Are you sure you want to exit the program?";
                string title = _currentLanguage == "Croatian" ? 
                    "Potvrda izlaska" : 
                    "Confirm Exit";
                
                MessageBoxResult result = MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true; // Cancel the closing operation
                }
            }
            
            base.OnClosing(e);
        }
    }

    public class MatchInfo
    {
        public string HomeTeam { get; set; }
        public string AwayTeam { get; set; }
        public string HomeTeamFifaCode { get; set; }
        public string AwayTeamFifaCode { get; set; }
        public int HomeScore { get; set; }
        public int AwayScore { get; set; }
        public bool IsYourTeamHome { get; set; }
        public List<PlayerInfoModel> HomeStartingEleven { get; set; } = new List<PlayerInfoModel>();
        public List<PlayerInfoModel> AwayStartingEleven { get; set; } = new List<PlayerInfoModel>();
        public string HomeTactics { get; set; }
        public string AwayTactics { get; set; }
        public List<MatchEvent> HomeTeamEvents { get; set; } = new List<MatchEvent>();
        public List<MatchEvent> AwayTeamEvents { get; set; } = new List<MatchEvent>();
    }

    public class MatchEvent
    {
        public int Id { get; set; }
        public string TypeOfEvent { get; set; }
        public string Player { get; set; }
        public string Time { get; set; }
    }

    public class PlayerInfoModel
    {
        public string Name { get; set; }
        public string Position { get; set; }
        public int ShirtNumber { get; set; }
        public bool IsCaptain { get; set; }
    }

    public class PlayerData
    {
        public string Name { get; set; }
        public int ShirtNumber { get; set; }
        public string ImageFileName { get; set; }
        public string TeamName { get; set; }
    }
}